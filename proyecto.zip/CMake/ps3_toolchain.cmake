# Toolchain CMake para PS3 (PSL1GHT + ps3toolchain, PPU).
# Uso:  cmake -G Ninja -B build-ps3 -DCMAKE_TOOLCHAIN_FILE=CMake/ps3_toolchain.cmake
# Requiere las variables de entorno PS3DEV y PSL1GHT (las de ps3toolchain):
#   export PS3DEV=/usr/local/ps3dev
#   export PSL1GHT=$PS3DEV
set(CMAKE_SYSTEM_NAME Generic)
set(CMAKE_SYSTEM_PROCESSOR powerpc64)

if(NOT DEFINED ENV{PS3DEV})
	set(ENV{PS3DEV} "/usr/local/ps3dev")
endif()
if(NOT DEFINED ENV{PSL1GHT})
	set(ENV{PSL1GHT} "$ENV{PS3DEV}")
endif()
set(PS3DEV  "$ENV{PS3DEV}")
set(PSL1GHT "$ENV{PSL1GHT}")
set(PS3_PPU "${PS3DEV}/ppu")

set(CMAKE_C_COMPILER   "${PS3DEV}/ppu/bin/powerpc64-ps3-elf-gcc")
set(CMAKE_CXX_COMPILER "${PS3DEV}/ppu/bin/powerpc64-ps3-elf-g++")
set(CMAKE_ASM_COMPILER "${PS3DEV}/ppu/bin/powerpc64-ps3-elf-gcc")
set(CMAKE_AR           "${PS3DEV}/ppu/bin/powerpc64-ps3-elf-gcc-ar")
set(CMAKE_RANLIB       "${PS3DEV}/ppu/bin/powerpc64-ps3-elf-gcc-ranlib")
set(CMAKE_STRIP        "${PS3DEV}/ppu/bin/powerpc64-ps3-elf-strip")

set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)
set(CMAKE_FIND_ROOT_PATH
	"${PS3_PPU}"
	"${PSL1GHT}/ppu"
	"${PS3DEV}/portlibs/ppu"
)
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_PACKAGE ONLY)

set(PS3 TRUE CACHE BOOL "Build for PlayStation 3" FORCE)

# El GCC de ps3toolchain es viejo (7.x): C++17 como maximo. Si algo no compila
# por C++20, bajarlo aqui en vez de tocar el codigo del juego.
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_compile_definitions(__PSL1GHT__)
add_compile_options(-mcpu=cell -mhard-float -O2 -Wall)
include_directories(SYSTEM
	"${PSL1GHT}/ppu/include"
	"${PS3DEV}/portlibs/ppu/include"
)
link_directories(
	"${PSL1GHT}/ppu/lib"
	"${PS3DEV}/portlibs/ppu/lib"
)
