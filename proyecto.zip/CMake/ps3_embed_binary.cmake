# Uso (modo script):
#   cmake -DINPUT=archivo.vpo -DOUTPUT=archivo_vpo.cpp -DSYMBOL=nombre -P ps3_embed_binary.cmake
# Convierte un binario en un .cpp con un array C exportado (extern "C"), alineado
# a 16 bytes. Equivale a bin2o, pero sin depender de que bin2s/bin2o existan.
if(NOT INPUT OR NOT OUTPUT OR NOT SYMBOL)
	message(FATAL_ERROR "faltan INPUT / OUTPUT / SYMBOL")
endif()
file(READ "${INPUT}" _hex HEX)
string(LENGTH "${_hex}" _hexlen)
if(_hexlen EQUAL 0)
	message(FATAL_ERROR "${INPUT} esta vacio")
endif()
math(EXPR _size "${_hexlen} / 2")
string(REGEX REPLACE "([0-9a-f][0-9a-f])" "0x\\1," _bytes "${_hex}")
file(WRITE "${OUTPUT}"
"// Generado por CMake/ps3_embed_binary.cmake desde ${INPUT}. No editar.
extern \"C\" {
extern const unsigned char ${SYMBOL}[] __attribute__((aligned(16)));
extern const unsigned int  ${SYMBOL}_size;
const unsigned char ${SYMBOL}[] __attribute__((aligned(16))) = {${_bytes}};
const unsigned int  ${SYMBOL}_size = ${_size};
}
")
