# Shaders del backend GL de PS3: .vcg/.fcg -> (cgcomp) .vpo/.fpo -> array C -> .cpp
#
# Se incluye desde la rama PS3 de CMakeLists.txt y deja en PS3GL_SHADER_SOURCES
# los .cpp generados (que definen ps3gl_vp_vpo, ps3gl_fp_flat_fpo y ps3gl_fp_tex_fpo).
#
# Orden de busqueda del binario compilado de cada shader:
#   1) cgcomp (PS3DEV/bin, PSL1GHT/host/bin o PATH): se compila en el build.
#   2) shaders/precompiled/<nombre>.vpo|.fpo (los deja ./build_shaders.sh).
# Si no hay ninguno de los dos, CMake aborta con instrucciones.
set(PS3GL_SHADER_DIR "${CMAKE_CURRENT_SOURCE_DIR}/SexyAppFramework/platform/ps3/gl/shaders")
set(PS3GL_SHADER_GEN "${CMAKE_BINARY_DIR}/ps3gl_shaders")
file(MAKE_DIRECTORY "${PS3GL_SHADER_GEN}")

find_program(PS3_CGCOMP cgcomp
	HINTS "$ENV{PS3DEV}/bin" "$ENV{PSL1GHT}/host/bin" "$ENV{PS3DEV}/host/bin"
	NO_CMAKE_FIND_ROOT_PATH)

# Flags de cgcomp para vertex / fragment (si tu version usa otros, pisalos con -D).
set(PS3_CGCOMP_VP_FLAG "-v" CACHE STRING "flag de cgcomp para vertex programs")
set(PS3_CGCOMP_FP_FLAG "-f" CACHE STRING "flag de cgcomp para fragment programs")

set(PS3GL_SHADER_SOURCES "")

function(ps3gl_add_shader src_file flag ext)
	get_filename_component(base "${src_file}" NAME_WE)
	set(src "${PS3GL_SHADER_DIR}/${src_file}")
	set(pre "${PS3GL_SHADER_DIR}/precompiled/${base}.${ext}")
	set(bin "${PS3GL_SHADER_GEN}/${base}.${ext}")
	set(cpp "${PS3GL_SHADER_GEN}/${base}_${ext}.cpp")

	if(PS3_CGCOMP)
		add_custom_command(OUTPUT "${bin}"
			COMMAND "${PS3_CGCOMP}" ${flag} "${src}" "${bin}"
			DEPENDS "${src}"
			COMMENT "cgcomp ${src_file}"
			VERBATIM)
	elseif(EXISTS "${pre}")
		add_custom_command(OUTPUT "${bin}"
			COMMAND "${CMAKE_COMMAND}" -E copy "${pre}" "${bin}"
			DEPENDS "${pre}"
			COMMENT "shader precompilado ${base}.${ext}"
			VERBATIM)
	else()
		message(FATAL_ERROR
			"No encuentro cgcomp ni ${pre}.\n"
			"Opciones: instalar cgcomp (PSL1GHT tools) y exportar PS3DEV, o compilar los "
			"shaders en otra maquina con ./build_shaders.sh y copiar shaders/precompiled/.")
	endif()

	add_custom_command(OUTPUT "${cpp}"
		COMMAND "${CMAKE_COMMAND}"
			-DINPUT=${bin} -DOUTPUT=${cpp} -DSYMBOL=${base}_${ext}
			-P "${CMAKE_CURRENT_SOURCE_DIR}/CMake/ps3_embed_binary.cmake"
		DEPENDS "${bin}" "${CMAKE_CURRENT_SOURCE_DIR}/CMake/ps3_embed_binary.cmake"
		COMMENT "embebiendo ${base}.${ext}"
		VERBATIM)

	set(PS3GL_SHADER_SOURCES ${PS3GL_SHADER_SOURCES} "${cpp}" PARENT_SCOPE)
endfunction()

ps3gl_add_shader(ps3gl_vp.vcg        "${PS3_CGCOMP_VP_FLAG}" vpo)
ps3gl_add_shader(ps3gl_fp_flat.fcg   "${PS3_CGCOMP_FP_FLAG}" fpo)
ps3gl_add_shader(ps3gl_fp_tex.fcg    "${PS3_CGCOMP_FP_FLAG}" fpo)
