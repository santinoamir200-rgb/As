#!/usr/bin/env bash
# Parte 6: arma el .self (para correr desde USB/HDD) y el .pkg (instalable) a partir de
# build-ps3/pvz_ps3.elf, con las herramientas de ps3toolchain / PSL1GHT.
#
# Uso:   ./build_ps3.sh && ./package_ps3.sh
#        ./package_ps3.sh --with-data /ruta/a/PvZ   (copia main.pak y properties/ al .pkg)
#
# SIN PROBAR: no tengo el toolchain. Los nombres de las herramientas y sus flags son los
# que recuerdo de ppu_rules de PSL1GHT; si alguno no existe en tu instalacion el script
# se detiene y te dice cual. Revisalos con:  ls $PS3DEV/bin
set -euo pipefail
cd "$(dirname "$0")"

export PS3DEV="${PS3DEV:-/usr/local/ps3dev}"
export PSL1GHT="${PSL1GHT:-$PS3DEV}"
export PATH="$PS3DEV/bin:$PS3DEV/ppu/bin:$PATH"

TITLE="Plants vs Zombies"
APPID="PVZPS3001"                              # 9 caracteres, sin guion
CONTENTID="UP0001-${APPID}_00-0000000000000000" # formato fijo: 36 caracteres
ELF="build-ps3/pvz_ps3.elf"
OUT="build-ps3/package"
DATA_DIR=""

while [ $# -gt 0 ]; do
	case "$1" in
		--with-data) DATA_DIR="${2:?falta la ruta}"; shift 2 ;;
		*) echo "opcion desconocida: $1" >&2; exit 1 ;;
	esac
done

# Carpetas donde PSL1GHT / ps3toolchain suelen dejar sus herramientas (segun la version).
SEARCH_DIRS=()
for d in "$PS3DEV/bin" "$PS3DEV/ppu/bin" "$PS3DEV/host/bin" "$PSL1GHT/bin" "$PSL1GHT/host/bin" \
         "$PSL1GHT/tools" "$PS3DEV/share" "$PS3DEV/ppu" "$PSL1GHT"; do
	[ -d "$d" ] && SEARCH_DIRS+=("$d")
done

find_tool() { # find_tool <nombre...>: PATH, luego find en las carpetas de arriba. Vacio si no esta.
	local n d f
	for n in "$@"; do
		if command -v "$n" >/dev/null 2>&1; then command -v "$n"; return 0; fi
	done
	for n in "$@"; do
		for d in "${SEARCH_DIRS[@]}"; do
			f="$(find "$d" -maxdepth 6 \( -type f -o -type l \) -name "$n" 2>/dev/null | head -n 1)"
			[ -n "$f" ] && { echo "$f"; return 0; }
		done
	done
	return 1
}

# Si falta algo, lo ultimo que se ve es este inventario: pegalo tal cual.
inventory() {
	echo "---------------- INVENTARIO (para diagnosticar) ----------------" >&2
	echo "PS3DEV=$PS3DEV  PSL1GHT=$PSL1GHT" >&2
	echo "--- ls $PS3DEV/bin ---" >&2
	ls "$PS3DEV/bin" 2>&1 | tr '\n' ' ' >&2; echo >&2
	echo "--- candidatos (sfo/pkg/fself/make_self/sprx) bajo $PS3DEV ---" >&2
	find "$PS3DEV" -maxdepth 6 \( -iname 'sfo*' -o -iname 'pkg*' -o -iname '*fself*' -o -iname 'make_self*' -o -iname 'sprx*' -o -iname 'ps3py*' \) \
		-not -path '*/include/*' -not -path '*/doc/*' -not -path '*/info/*' 2>/dev/null | head -40 >&2
	echo "--- *.py bajo $PS3DEV ---" >&2
	find "$PS3DEV" -maxdepth 6 -name '*.py' 2>/dev/null | head -20 >&2
	echo "--- sfo.xml bajo $PS3DEV ---" >&2
	find "$PS3DEV" -maxdepth 6 -name 'sfo.xml' 2>/dev/null | head -5 >&2
	echo "----------------------------------------------------------------" >&2
}

need() { # need <nombre> <alternativa...>: devuelve la ruta de la primera que exista
	local r
	if r="$(find_tool "$@")"; then echo "$r"; return 0; fi
	echo "ERROR: no encuentro ninguna de estas herramientas: $*" >&2
	echo "       (buscadas en PATH y en: ${SEARCH_DIRS[*]})" >&2
	inventory
	exit 1
}

# Los .py se lanzan con python; los binarios (make_fself, etc.) se ejecutan directo.
run_tool() { # run_tool <ruta> args...
	local t="$1"; shift
	case "$t" in
		*.py) "$PYTHON" "$t" "$@" ;;
		*) if head -c 64 "$t" 2>/dev/null | grep -q 'python'; then "$PYTHON" "$t" "$@"; else "$t" "$@"; fi ;;
	esac
}

[ -f "$ELF" ] || { echo "ERROR: falta $ELF. Corre ./build_ps3.sh primero." >&2; exit 1; }

SPRXLINKER="$(need sprxlinker)"
FSELF="$(need fself.py fself make_fself)"
MAKE_SELF_NPDRM="$(need make_self_npdrm)"
SFO="$(need sfo.py sfo)"
PKGTOOL="$(need pkg.py pkg)"
PYTHON="$(need python3 python2 python)"
STRIP="$(need ppu-strip powerpc64-ps3-elf-strip)"

# sfo.xml viene con PSL1GHT; la ruta exacta varia segun la version.
SFOXML="$(find_tool sfo.xml || true)"
[ -n "$SFOXML" ] || { echo "ERROR: no encuentro sfo.xml." >&2; inventory; exit 1; }
echo "herramientas: sprxlinker=$SPRXLINKER fself=$FSELF npdrm=$MAKE_SELF_NPDRM sfo=$SFO pkg=$PKGTOOL sfo.xml=$SFOXML"

rm -rf "$OUT"
mkdir -p "$OUT/pkg/USRDIR"

echo "[1/5] strip + sprxlinker"
cp "$ELF" "$OUT/pvz_ps3.stripped.elf"
"$STRIP" "$OUT/pvz_ps3.stripped.elf"
run_tool "$SPRXLINKER" "$OUT/pvz_ps3.stripped.elf"

echo "[2/5] .self (para correr sin instalar)"
run_tool "$FSELF" "$OUT/pvz_ps3.stripped.elf" "$OUT/pvz_ps3.self"

echo "[3/5] EBOOT.BIN firmado (para el .pkg)"
run_tool "$MAKE_SELF_NPDRM" "$OUT/pvz_ps3.stripped.elf" "$OUT/pkg/USRDIR/EBOOT.BIN" "$CONTENTID"

echo "[4/5] PARAM.SFO e ICON0.PNG"
run_tool "$SFO" --title "$TITLE" --appid "$APPID" -f "$SFOXML" "$OUT/pkg/PARAM.SFO"
if [ -f icon.png ]; then
	# El XMB espera 320x176. Si hay ImageMagick lo ajusta; si no, copia tal cual.
	if command -v convert >/dev/null 2>&1; then
		convert icon.png -resize 320x176 -background black -gravity center -extent 320x176 "$OUT/pkg/ICON0.PNG"
	else
		cp icon.png "$OUT/pkg/ICON0.PNG"
		echo "  aviso: sin ImageMagick; icon.png se copio sin redimensionar (ideal 320x176)"
	fi
else
	echo "  aviso: no hay icon.png; el .pkg queda sin icono"
fi

if [ -n "$DATA_DIR" ]; then
	echo "      copiando datos del juego desde $DATA_DIR"
	[ -f "$DATA_DIR/main.pak" ] || { echo "ERROR: no hay main.pak en $DATA_DIR" >&2; exit 1; }
	cp "$DATA_DIR/main.pak" "$OUT/pkg/USRDIR/"
	[ -d "$DATA_DIR/properties" ] && cp -r "$DATA_DIR/properties" "$OUT/pkg/USRDIR/"
fi

echo "[5/5] .pkg"
run_tool "$PKGTOOL" --contentid "$CONTENTID" "$OUT/pkg/" "$OUT/pvz_ps3.pkg"

echo
echo "Listo:"
echo "  $OUT/pvz_ps3.self   (ejecutar sin instalar)"
echo "  $OUT/pvz_ps3.pkg    (instalar desde el XMB / gestor de paquetes)"
[ -n "$DATA_DIR" ] || echo "Recuerda: main.pak y properties/ van en /dev_usb000/PVZ o junto al EBOOT."
