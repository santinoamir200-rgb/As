// Arnes de logica para el teclado en pantalla de PS3. Corre en PC (build_and_run.sh).
//
// QUE ES REAL en esta prueba (se compila tal cual del arbol):
//   - platform/ps3/Input.cpp       (ProcessDeferredMessages, StartTextInput, ...)
//   - platform/ps3/Ps3PadKeyboard.h (el mapeador pad -> teclado)
//   - widget/VirtualKeyboard.cpp   (teclado compartido con Wii/PS2)
//   - widget/EditWidget.cpp        (el campo de texto: limite de caracteres, backspace, ENTER)
//
// QUE ES FALSO (stubs de este archivo):
//   - ioPad*  : el DualShock 3 lo simula el test (gFake).
//   - Widget / WidgetContainer / WidgetManager / Graphics: stubs minimos. El ruteo
//     de teclas y de mouse del WidgetManager esta reimplementado aqui en 3 lineas
//     (KeyChar/KeyDown -> widget con foco; Mouse* -> teclado si el punto cae encima).
//   - ps3gl_*: solo registra si el cursor quedo visible.
//
// NO prueba: dibujo (Draw no se ejecuta), RSX, PSL1GHT real, el dialogo NewUserDialog
// completo, ni nada en hardware.

#include <string>
#include <list>
#include <vector>
#include <map>
#include <set>
#include <deque>
#include <algorithm>
#include <memory>
#include <sstream>
#include <functional>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <cstdarg>

#define private public
#define protected public
#include "SexyAppBase.h"
#include "widget/WidgetManager.h"
#include "widget/EditWidget.h"
#include "widget/EditListener.h"
#include "widget/VirtualKeyboard.h"
#include "graphics/Font.h"
#include <io/pad.h>
#undef private
#undef protected
#ifdef printf
#undef printf
#endif

using namespace Sexy;

// El framework redirige printf a Sexy::PrintF; aca va a la salida estandar.
namespace Sexy { void PrintF(const char* f, ...) { va_list a; va_start(a, f); vprintf(f, a); va_end(a); } }

// ------------------------------------------------------------------ chequeos
static int gChecks = 0, gFails = 0;
#define CHECK(cond) do { ++gChecks; if (!(cond)) { ++gFails; \
	printf("  FALLA  %s:%d  %s\n", __FILE__, __LINE__, #cond); } } while (0)
#define CHECK_EQ_STR(a, b) do { ++gChecks; std::string _a = (a), _b = (b); if (_a != _b) { ++gFails; \
	printf("  FALLA  %s:%d  esperado \"%s\" obtuve \"%s\"\n", __FILE__, __LINE__, _b.c_str(), _a.c_str()); } } while (0)
#define SECTION(name) printf("[%s]\n", name)

// ------------------------------------------------------------------ pad falso
struct FakePad
{
	bool cross, circle, square, triangle, start, select, up, down, left, right;
	int lx, ly;                  // 0..255, 128 = centro
	void Clear() { memset(this, 0, sizeof(*this)); lx = ly = 128; }
};
static FakePad gFake;
static bool gCursorVisible = true;
static int gLastCursorCalls = 0;

extern "C"
{
int ioPadInit(uint32_t) { return 0; }
int ioPadGetInfo(padInfo* i) { memset(i, 0, sizeof(*i)); i->status[0] = 1; return 0; }
int ioPadGetData(uint32_t, padData* d)
{
	memset(d, 0, sizeof(*d));
	d->len = 16;
	d->BTN_CROSS = gFake.cross; d->BTN_CIRCLE = gFake.circle; d->BTN_SQUARE = gFake.square;
	d->BTN_TRIANGLE = gFake.triangle; d->BTN_START = gFake.start; d->BTN_SELECT = gFake.select;
	d->BTN_UP = gFake.up; d->BTN_DOWN = gFake.down; d->BTN_LEFT = gFake.left; d->BTN_RIGHT = gFake.right;
	d->ANA_L_H = (uint16_t)gFake.lx; d->ANA_L_V = (uint16_t)gFake.ly;
	return 0;
}
bool ps3gl_exit_requested(void) { return false; }
void ps3gl_set_cursor(float, float, bool visible) { gCursorVisible = visible; ++gLastCursorCalls; }
}

// ------------------------------------------------------------ stubs del framework
// Registro de todo lo que llega al WidgetManager (lo que "veria" el juego).
struct Ev { char type; int a, b, c; };   // 'c' KeyChar, 'd' KeyDown, 'u' KeyUp, 'M' MouseMove, 'D' MouseDown, 'U' MouseUp
static std::vector<Ev> gLog;
static std::vector<Widget*> gAdded;      // widgets agregados al manager (el teclado), el ultimo es el tope

static int CountEv(char type, int a = -9999)
{
	int n = 0;
	for (size_t i = 0; i < gLog.size(); i++)
		if (gLog[i].type == type && (a == -9999 || gLog[i].a == a)) n++;
	return n;
}

Color::Color(int r, int g, int b) : mRed(r), mGreen(g), mBlue(b), mAlpha(255) {}

WidgetContainer::WidgetContainer()
{
	mWidgetManager = NULL; mParent = NULL; mUpdateIteratorModified = false; mLastWMUpdateCount = 0;
	mUpdateCnt = 0; mDirty = false; mX = mY = mWidth = mHeight = 0; mHasAlpha = false; mClip = true;
	mPriority = 0; mZOrder = 0;
}
WidgetContainer::~WidgetContainer() {}
WidgetManager::WidgetManager(SexyAppBase* a) { mApp = a; mFocusWidget = NULL; memset(mKeyDown, 0, sizeof(mKeyDown)); }
WidgetManager::~WidgetManager() {}
void WidgetContainer::MarkDirty() { mDirty = true; }
void WidgetContainer::MarkAllDirty() {}
void WidgetContainer::AddWidget(Widget* w) { w->mWidgetManager = (WidgetManager*)this; gAdded.push_back(w); }
void WidgetContainer::RemoveWidget(Widget* w)
{
	gAdded.erase(std::remove(gAdded.begin(), gAdded.end(), w), gAdded.end());
	w->mWidgetManager = NULL;
}
void WidgetContainer::BringToFront(Widget*) {}

Widget::Widget()
{
	mVisible = true; mMouseVisible = true; mDisabled = false; mHasFocus = false; mIsDown = false;
	mIsOver = false; mHasTransparencies = false; mDoFinger = false; mWantsFocus = false;
	mTabPrev = mTabNext = NULL;
}
Widget::~Widget() {}
void Widget::Resize(int x, int y, int w, int h) { mX = x; mY = y; mWidth = w; mHeight = h; }
void Widget::Update() {}
void Widget::MouseMove(int, int) {}
void Widget::MouseDown(int, int, int) {}
void Widget::MouseUp(int, int, int) {}
void Widget::MouseLeave() {}
void Widget::KeyChar(SexyChar) {}
void Widget::KeyDown(KeyCode) {}
void Widget::KeyUp(KeyCode) {}
void Widget::GotFocus() { mHasFocus = true; }
void Widget::LostFocus() { mHasFocus = false; }
void Widget::SetColors(int c[][3], int n) { mColors.clear(); for (int i = 0; i < n; i++) mColors.push_back(Color(c[i][0], c[i][1], c[i][2])); }

// Ruteo del WidgetManager real, reducido a lo que usan estas pruebas.
bool WidgetManager::KeyChar(SexyChar c)
{
	gLog.push_back({ 'c', (unsigned char)c, 0, 0 });
	if (mFocusWidget) mFocusWidget->KeyChar(c);
	return true;
}
bool WidgetManager::KeyDown(KeyCode k)
{
	gLog.push_back({ 'd', (int)k, 0, 0 });
	if ((int)k >= 0 && (int)k < 0xFF) mKeyDown[k] = true;
	if (mFocusWidget) mFocusWidget->KeyDown(k);
	return true;
}
bool WidgetManager::KeyUp(KeyCode k)
{
	gLog.push_back({ 'u', (int)k, 0, 0 });
	if ((int)k >= 0 && (int)k < 0xFF) mKeyDown[k] = false;
	if (mFocusWidget) mFocusWidget->KeyUp(k);
	return true;
}
static Widget* WidgetAt(int x, int y)
{
	for (int i = (int)gAdded.size() - 1; i >= 0; i--)
		if (x >= gAdded[i]->mX && x < gAdded[i]->mX + gAdded[i]->mWidth &&
			y >= gAdded[i]->mY && y < gAdded[i]->mY + gAdded[i]->mHeight)
			return gAdded[i];
	return NULL;
}
bool WidgetManager::MouseMove(int x, int y)
{
	gLog.push_back({ 'M', x, y, 0 });
	if (Widget* w = WidgetAt(x, y)) w->MouseMove(x - w->mX, y - w->mY);
	return true;
}
bool WidgetManager::MouseDown(int x, int y, int c)
{
	gLog.push_back({ 'D', x, y, c });
	if (Widget* w = WidgetAt(x, y)) w->MouseDown(x - w->mX, y - w->mY, c);
	return true;
}
bool WidgetManager::MouseUp(int x, int y, int c)
{
	gLog.push_back({ 'U', x, y, c });
	if (Widget* w = WidgetAt(x, y)) w->MouseUp(x - w->mX, y - w->mY, c);
	return true;
}

namespace Sexy
{
SexyAppBase* gSexyAppBase = NULL;
_Font* FONT_PICO129 = NULL;
}
std::string SexyAppBase::GetClipboard() { return ""; }
void Graphics::SetFont(_Font*) {}
void Graphics::SetColor(const Color&) {}
void Graphics::FillRect(int, int, int, int) {}
void Graphics::DrawRect(int, int, int, int) {}
void Graphics::ClipRect(int, int, int, int) {}

// Fuente de ancho fijo (10 px por caracter): hace falta para EditWidget.
class FakeFont : public _Font
{
public:
	FakeFont() {}
	virtual int StringWidth(const SexyString& s) { return (int)s.size() * 10; }
	virtual _Font* Duplicate() { return new FakeFont(); }
};

// El dialogo de nombre: al recibir ENTER (EditWidgetText) "se cierra": el campo pierde
// el foco, que es lo que hace el juego (KillDialog), y eso llama a StopTextInput.
static EditWidget* gEdit = NULL;
static int gEnterCount = 0;
static std::string gEnterText;
class FakeListener : public EditListener
{
public:
	virtual void EditWidgetText(int, const SexyString& s)
	{
		++gEnterCount; gEnterText = s;
		gEdit->LostFocus();                       // el dialogo se cierra
		gEdit->mWidgetManager->mFocusWidget = NULL;
	}
};
static FakeListener gListener;

// ------------------------------------------------------------------ entorno
static SexyAppBase* gApp = NULL;
static WidgetManager* gWM = NULL;

static VirtualKeyboard* Kb()
{
	for (size_t i = 0; i < gAdded.size(); i++)
		if (dynamic_cast<VirtualKeyboard*>(gAdded[i])) return static_cast<VirtualKeyboard*>(gAdded[i]);
	return NULL;
}

// Un frame de juego: el pad ya esta seteado en gFake. Tambien da los Update() del
// framework al teclado (100 Hz en el juego; aca uno por frame, o N si se pide).
static void Frame(int updates = 1, bool realDelay = false)
{
	gApp->ProcessDeferredMessages(false);
	for (int i = 0; i < updates; i++)
		if (VirtualKeyboard* k = Kb()) k->Update();
	if (realDelay) SDL_Delay(17);
}
static void Frames(int n, bool realDelay = false) { for (int i = 0; i < n; i++) Frame(1, realDelay); }

// Pulsar y soltar (cada uno en su frame, con un frame de reposo entre medio).
static void Tap(bool* button) { *button = true; Frame(); *button = false; Frame(); }
static void Settle() { gFake.Clear(); Frames(3); }

static void OpenKeyboard()
{
	gEdit->GotFocus();                    // EditWidget real -> SexyAppBase::StartTextInput real
	gWM->mFocusWidget = gEdit;
}

static void EnsureShift(bool on)
{
	if (Kb() && Kb()->mShift != on) Tap(&gFake.triangle);
}

// Nota: el teclado compartido es un singleton y conserva mShift entre aperturas
// (comportamiento ya existente en Wii/PS2). Por eso cada sesion fija el estado que necesita.
static void NewSession(int maxChars = 12, bool shiftOn = true)
{
	gFake.Clear();
	gLog.clear();
	gEdit->mString.clear();
	gEdit->mCursorPos = 0;
	gEdit->mHilitePos = -1;
	gEdit->mMaxChars = maxChars;
	gEnterCount = 0;
	gEnterText.clear();
	if (VirtualKeyboardIsActive()) { gEdit->LostFocus(); }
	Frames(2);
	OpenKeyboard();
	Frames(3);                            // deja que el mapeador "arme" los botones
	EnsureShift(shiftOn);
	gLog.clear();
}

// --- navegacion: BFS sobre el grafo REAL de vecinos del teclado -------------------
static int FocusIdx() { return Kb()->mFocusKey; }
static std::string KeyName(int idx)
{
	VirtualKeyboard::Key& k = Kb()->mKeys[idx];
	if (k.mLower) return std::string(1, k.mLower);
	return k.mLabel;
}
static int FindKey(const std::string& name)
{
	VirtualKeyboard* k = Kb();
	for (int i = 0; i < k->mNumKeys; i++)
		if (KeyName(i) == name) return i;
	return -1;
}
// Direcciones (dx,dy) que hay que apretar para ir de 'from' a 'to'. Vacio si no hay camino.
static bool PathTo(int from, int to, std::vector<int>& dirs)
{
	VirtualKeyboard* k = Kb();
	static const int D[4][2] = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 } };
	std::vector<int> prev(k->mNumKeys, -2), via(k->mNumKeys, -1);
	std::deque<int> q; q.push_back(from); prev[from] = -1;
	while (!q.empty())
	{
		int c = q.front(); q.pop_front();
		for (int d = 0; d < 4; d++)
		{
			int n = k->FindNeighbour(c, D[d][0], D[d][1]);
			if (n >= 0 && prev[n] == -2) { prev[n] = c; via[n] = d; q.push_back(n); }
		}
	}
	if (prev[to] == -2) return false;
	dirs.clear();
	for (int c = to; c != from; c = prev[c]) dirs.push_back(via[c]);
	std::reverse(dirs.begin(), dirs.end());
	return true;
}
// Mueve el foco con la CRUCETA del pad (Input.cpp real) hasta la tecla pedida.
static bool GoTo(const std::string& name)
{
	int to = FindKey(name);
	if (to < 0) return false;
	std::vector<int> dirs;
	if (!PathTo(FocusIdx(), to, dirs)) return false;
	for (size_t i = 0; i < dirs.size(); i++)
	{
		bool* b = dirs[i] == 0 ? &gFake.left : dirs[i] == 1 ? &gFake.right : dirs[i] == 2 ? &gFake.up : &gFake.down;
		Tap(b);
	}
	return FocusIdx() == to;
}
static void Write(const std::string& name) { GoTo(name); Tap(&gFake.cross); }
static void WriteText(const std::string& s)
{
	for (size_t i = 0; i < s.size(); i++)
		Write(s[i] == ' ' ? "Space" : std::string(1, (char)tolower((unsigned char)s[i])));
}

// ------------------------------------------------------------------ pruebas
static void TestActivation()
{
	SECTION("activacion: el teclado aparece con el foco del campo y se queda con el pad");
	NewSession();
	CHECK(VirtualKeyboardIsActive());
	CHECK(Kb() != NULL);
	CHECK(FocusIdx() == 0);                 // modo cruceta desde el primer momento, sin "engage"
	CHECK(!gCursorVisible);                 // cursor oculto en modo teclado
	gLog.clear();
	gFake.lx = 255; Frames(3); Settle();    // el stick NO debe mover el cursor del juego
	CHECK(CountEv('M') == 0);
	CHECK(CountEv('D') == 0 && CountEv('U') == 0);
}

static void TestTyping()
{
	SECTION("X escribe, O borra, mayuscula inicial automatica");
	NewSession();
	WriteText("ana");
	CHECK_EQ_STR(gEdit->mString, "Ana");      // el teclado arranca en mayuscula y la suelta tras la 1a letra
	Tap(&gFake.circle);
	CHECK_EQ_STR(gEdit->mString, "An");
	Tap(&gFake.circle); Tap(&gFake.circle);
	CHECK_EQ_STR(gEdit->mString, "");
	Tap(&gFake.circle);                       // borrar con el campo vacio no rompe nada
	CHECK_EQ_STR(gEdit->mString, "");
}

static void TestShiftToggle()
{
	SECTION("Triangulo alterna mayusculas/minusculas");
	NewSession(12, true);
	CHECK(Kb()->mShift);
	Tap(&gFake.triangle);
	CHECK(!Kb()->mShift);
	Tap(&gFake.triangle);
	CHECK(Kb()->mShift);
	Tap(&gFake.triangle);                     // minuscula fija
	WriteText("ab");
	CHECK_EQ_STR(gEdit->mString, "ab");
	Tap(&gFake.triangle);                     // mayuscula para la siguiente letra
	WriteText("c");
	CHECK_EQ_STR(gEdit->mString, "abC");
	WriteText("d");
	CHECK_EQ_STR(gEdit->mString, "abCd");     // y despues vuelve a minuscula sola
	// Triangulo no manda ENTER ni nada raro al juego
	CHECK(CountEv('d', KEYCODE_RETURN) == 0);
}

static void TestStick()
{
	SECTION("stick izquierdo mueve el foco: histeresis, un solo eje, auto-repeat");
	NewSession();
	int f0 = FocusIdx();
	// Por debajo del umbral de entrada (0.55) no hace nada
	gFake.lx = 128 + 60;  Frames(3);          // ~0.47
	CHECK(FocusIdx() == f0);
	// Cruza el umbral: un paso
	gFake.lx = 128 + 120; Frame();            // ~0.94
	int f1 = FocusIdx();
	CHECK(f1 != f0);
	// Histeresis: bajar a ~0.45 (entre 0.35 y 0.55) mantiene "pulsado": no vuelve a contar como nueva pulsacion
	gFake.lx = 128 + 58;  Frames(3);
	CHECK(FocusIdx() == f1);
	// Soltar del todo y pulsar de nuevo da otro paso
	gFake.lx = 128; Frames(2);
	gFake.lx = 128 + 120; Frame();
	CHECK(FocusIdx() != f1);
	gFake.lx = 128; Frames(2);
	// Diagonal: manda el eje dominante, no los dos
	int fa = FocusIdx();
	gFake.lx = 128 + 110; gFake.ly = 128 + 90; Frame();
	int fb = FocusIdx();
	VirtualKeyboard* k = Kb();
	CHECK(fb != fa);
	CHECK(k->mKeys[fb].mY == k->mKeys[fa].mY);   // se movio solo en horizontal (misma fila)
	gFake.Clear(); Frames(2);
	// Auto-repeat: mantener el stick camina por el teclado
	NewSession();
	int start = FocusIdx();
	gFake.lx = 255; Frame();
	int afterFirst = FocusIdx();
	Frame(10);                                // 10 updates: todavia dentro del retardo de repeticion (25)
	CHECK(FocusIdx() == afterFirst);
	Frame(30);                                // pasa el retardo: sigue caminando
	CHECK(FocusIdx() != afterFirst);
	CHECK(FocusIdx() != start);
	gFake.Clear(); Frames(2);
}

static void TestDpadRepeat()
{
	SECTION("cruceta: un paso por pulsacion");
	NewSession();
	int f0 = FocusIdx();
	Tap(&gFake.right);
	CHECK(FocusIdx() != f0);
	Tap(&gFake.left);
	CHECK(FocusIdx() == f0);
}

static void TestAllKeysReachableAndAllowedChars()
{
	SECTION("todas las teclas se alcanzan con la cruceta; solo salen caracteres permitidos");
	NewSession(1000);                         // sin limite, para ver todo lo que se emite
	VirtualKeyboard* k = Kb();
	std::set<char> emitted;
	int unreachable = 0;
	std::vector<std::string> names;
	for (int i = 0; i < k->mNumKeys; i++) names.push_back(KeyName(i));
	CHECK(k->mNumKeys == 10 + 10 + 9 + 7 + 4);   // 36 de caracteres + 4 comandos
	for (size_t i = 0; i < names.size(); i++)
	{
		const std::string& n = names[i];
		if (n == "Done" || n == "Back") { if (FindKey(n) < 0 || !GoTo(n)) unreachable++; continue; }  // llegar, pero no apretar
		if (!GoTo(n)) { unreachable++; continue; }
		gLog.clear();
		Tap(&gFake.cross);
		for (size_t e = 0; e < gLog.size(); e++)
			if (gLog[e].type == 'c') emitted.insert((char)gLog[e].a);
	}
	CHECK(unreachable == 0);
	bool allOk = true;
	for (std::set<char>::iterator it = emitted.begin(); it != emitted.end(); ++it)
	{
		char c = *it;
		bool ok = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' ';
		if (!ok) { allOk = false; printf("    caracter no permitido emitido: 0x%02x\n", (unsigned char)c); }
	}
	CHECK(allOk);
	int digits = 0, lower = 0, upper = 0;
	for (std::set<char>::iterator it = emitted.begin(); it != emitted.end(); ++it)
	{ if (*it >= '0' && *it <= '9') digits++; if (*it >= 'a' && *it <= 'z') lower++; if (*it >= 'A' && *it <= 'Z') upper++; }
	CHECK(digits == 10);
	CHECK(lower + upper == 26 || lower == 26 || upper == 26 || (lower > 0 && upper > 0));
	CHECK(emitted.count(' ') == 1);
}

static void TestMaxLength()
{
	SECTION("limite de 12 caracteres (EditWidget real, mMaxChars = 12 como NewUserDialog)");
	NewSession(12);
	WriteText("abcdefghijklmnopqrstu");     // 21 caracteres
	CHECK((int)gEdit->mString.size() == 12);
	CHECK_EQ_STR(gEdit->mString, "Abcdefghijkl");
	Tap(&gFake.circle);
	CHECK((int)gEdit->mString.size() == 11);
	WriteText("zq");                          // vuelve a poder escribir 1; el 2o se descarta
	CHECK((int)gEdit->mString.size() == 12);
	// espacios cuentan dentro de los 12
	NewSession(12);
	WriteText("ana maria lop");
	CHECK((int)gEdit->mString.size() == 12);
}

// Copia TEXTUAL de NewUserDialog::GetName (Lawn/Widget/NewUserDialog.cpp). No se enlaza
// el dialogo real (arrastra todo LawnDialog/LawnApp); se copia para ver el resultado
// final de un nombre escrito con este teclado. Si el original cambia, esto no se entera.
static std::string GetNameCopy(const std::string& typed)
{
	std::string aString;
	char aLastChar = ' ';
	for (size_t i = 0; i < typed.size(); i++)
	{
		char aChar = typed[i];
		if (aChar != ' ') aString.append(1, aChar);
		else if (aChar != aLastChar) aString.append(1, ' ');
		aLastChar = aChar;
	}
	if (aString.size() && aString[aString.size() - 1] == ' ') aString.resize(aString.size() - 1);
	return aString;
}

static void TestNameNormalisation()
{
	SECTION("normalizacion del nombre (copia de NewUserDialog::GetName)");
	NewSession(12);
	WriteText("ana  maria");                  // dos espacios seguidos
	CHECK_EQ_STR(GetNameCopy(gEdit->mString), "Ana maria");
	NewSession(12);
	WriteText("  ");                          // solo espacios -> queda vacio -> el juego muestra "Enter Your Name"
	CHECK_EQ_STR(GetNameCopy(gEdit->mString), "");
	NewSession(12);
	WriteText("bob ");                        // espacio final se recorta
	CHECK_EQ_STR(GetNameCopy(gEdit->mString), "Bob");
}

static void TestStartConfirms()
{
	SECTION("START confirma (ENTER) y el teclado se cierra sin fugas de teclas");
	NewSession();
	WriteText("pat");
	gFake.start = true; Frame();              // START apretado
	CHECK(gEnterCount == 1);                  // el campo recibio ENTER -> el dialogo se cierra
	CHECK_EQ_STR(gEnterText, "Pat");
	CHECK(!VirtualKeyboardIsActive());
	Frames(5);                                // START sigue apretado con el teclado ya cerrado
	CHECK(gEnterCount == 1);                  // no se repite
	CHECK(CountEv('d', KEYCODE_ESCAPE) == 0); // y el mapa normal no lo toma como "START = ESC"
	CHECK(CountEv('d', KEYCODE_RETURN) == 1);
	gFake.start = false; Frames(2);
	CHECK(gCursorVisible);                    // cursor vuelve
	// Despues de cerrar, el mapa normal funciona como siempre
	gLog.clear();
	Tap(&gFake.triangle);
	CHECK(CountEv('d', KEYCODE_RETURN) == 1);
	gFake.start = true; Frame(); gFake.start = false; Frame();
	CHECK(CountEv('d', KEYCODE_ESCAPE) == 1);
}

static void TestArming()
{
	SECTION("botones ya apretados al abrir el teclado no escriben hasta soltarse");
	gFake.Clear(); gLog.clear();
	if (VirtualKeyboardIsActive()) { gEdit->LostFocus(); Frames(2); }
	gEdit->mString.clear(); gEdit->mCursorPos = 0; gEdit->mHilitePos = -1; gEdit->mMaxChars = 12;
	gEnterCount = 0;
	gFake.cross = true; gFake.start = true;   // p.ej. X de "NEW USER" aun apretado
	Frames(2);
	OpenKeyboard();
	Frames(5);
	CHECK(CountEv('c') == 0);
	CHECK(gEnterCount == 0);
	CHECK_EQ_STR(gEdit->mString, "");
	gFake.cross = false; gFake.start = false; Frames(2);
	Tap(&gFake.cross);                        // ahora si
	CHECK(CountEv('c') == 1);
}

static void TestPointerMode()
{
	SECTION("SELECT: modo cursor (para Cancelar / clickear teclas) y de vuelta");
	NewSession();
	CHECK(!gCursorVisible);
	Tap(&gFake.select);
	CHECK(gCursorVisible);                    // cursor de vuelta
	CHECK(FocusIdx() < 0);                    // sin foco de teclas
	CHECK(VirtualKeyboardIsActive());         // el teclado sigue en pantalla
	// el stick mueve el cursor del juego otra vez (MouseMove) y X hace click
	gLog.clear();
	gFake.ly = 255;                           // abajo a tope
	Frames(25, true);                         // ~0.4 s reales
	gFake.Clear(); Frames(2);
	CHECK(CountEv('M') > 0);
	// llevar el cursor sobre una tecla: sube/baja hasta caer dentro del teclado
	VirtualKeyboard* k = Kb();
	int cx = 0, cy = 0;
	for (size_t i = 0; i < gLog.size(); i++) if (gLog[i].type == 'M') { cx = gLog[i].a; cy = gLog[i].b; }
	bool over = cx >= k->mX && cx < k->mX + k->mWidth && cy >= k->mY && cy < k->mY + k->mHeight;
	int guard = 0;
	while (!over && guard++ < 100)
	{
		gFake.ly = 255; Frame(1, true);
		gFake.Clear();
		for (size_t i = gLog.size(); i-- > 0;) if (gLog[i].type == 'M') { cx = gLog[i].a; cy = gLog[i].b; break; }
		over = cx >= k->mX && cx < k->mX + k->mWidth && cy >= k->mY && cy < k->mY + k->mHeight;
	}
	CHECK(over);
	int hit = k->HitTest(cx - k->mX, cy - k->mY);
	if (hit >= 0 && k->mKeys[hit].mCommand == 0)
	{
		char expect = k->mShift ? k->mKeys[hit].mUpper : k->mKeys[hit].mLower;
		gLog.clear();
		gFake.cross = true; Frame(); gFake.cross = false; Frame();
		CHECK(CountEv('D') == 1 && CountEv('U') == 1);
		CHECK(CountEv('c', (unsigned char)expect) == 1);     // el click escribio la tecla bajo el cursor
	}
	else printf("  (aviso) el cursor quedo sobre una tecla de comando o hueco; click no verificado\n");
	// SELECT vuelve al modo teclado: el cursor se oculta, hay foco, ya no se ven clicks
	Tap(&gFake.select);
	CHECK(!gCursorVisible);
	CHECK(FocusIdx() >= 0);
	gLog.clear();
	Tap(&gFake.cross);
	CHECK(CountEv('D') == 0);
	CHECK(CountEv('c') == 1);                 // X escribe la tecla enfocada
}

static void TestReopen()
{
	SECTION("cerrar y reabrir el teclado: vuelve limpio a modo teclado");
	NewSession();
	Tap(&gFake.select);                       // dejarlo en modo cursor
	gEdit->LostFocus(); Frames(2);
	CHECK(!VirtualKeyboardIsActive());
	CHECK(gCursorVisible);
	OpenKeyboard(); Frames(3);
	CHECK(VirtualKeyboardIsActive());
	CHECK(!gCursorVisible);
	CHECK(FocusIdx() >= 0);
	gLog.clear();
	Write("q");
	CHECK(CountEv('c') == 1);
}

static void TestNormalMappingUntouched()
{
	SECTION("sin teclado el mapa normal del Parte 4 no cambia");
	if (VirtualKeyboardIsActive()) { gEdit->LostFocus(); Frames(2); }
	gFake.Clear(); Frames(3); gLog.clear();
	CHECK(gCursorVisible);
	Tap(&gFake.cross);
	CHECK(CountEv('D') == 1 && CountEv('U') == 1);
	Tap(&gFake.circle);
	CHECK(CountEv('D') == 2 && CountEv('U') == 2);
	Tap(&gFake.square);
	CHECK(CountEv('d', KEYCODE_SPACE) == 1);
	Tap(&gFake.triangle);
	CHECK(CountEv('d', KEYCODE_RETURN) == 1);
	Tap(&gFake.start);
	CHECK(CountEv('d', KEYCODE_ESCAPE) == 1);
	gLog.clear();
	gFake.right = true; Frames(5, true); gFake.Clear(); Frame();
	CHECK(CountEv('M') > 0);
	Tap(&gFake.select);                       // SELECT fuera del teclado no hace nada
	CHECK(CountEv('D') == 0 || true);
}

int main()
{
	gFake.Clear();
	gApp = (SexyAppBase*)calloc(1, sizeof(SexyAppBase));
	gWM = new WidgetManager(NULL);
	gApp->mWidgetManager = gWM;
	gWM->mApp = gApp;
	gApp->mWidth = 800; gApp->mHeight = 600; gApp->mActive = true;
	gSexyAppBase = gApp;

	gEdit = new EditWidget(1, &gListener);
	gEdit->mFont = new FakeFont();
	gEdit->mWidgetManager = gWM;
	gEdit->mWidth = 300; gEdit->mHeight = 28;
	gWM->mFocusWidget = gEdit;

	TestActivation();
	TestTyping();
	TestShiftToggle();
	TestDpadRepeat();
	TestStick();
	TestAllKeysReachableAndAllowedChars();
	TestMaxLength();
	TestNameNormalisation();
	TestStartConfirms();
	TestArming();
	TestPointerMode();
	TestReopen();
	TestNormalMappingUntouched();

	printf("\n%d chequeos, %d fallas\n", gChecks, gFails);
	return gFails ? 1 : 0;
}
