#!/bin/bash
# Compila y corre el arnes de logica del teclado en pantalla en una PC con g++.
# No necesita el toolchain de PS3 ni PSL1GHT. Uso (desde cualquier lado):
#   bash SexyAppFramework/platform/ps3/test_osk/build_and_run.sh
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../../.." && pwd)"
OUT="${TMPDIR:-/tmp}/pvz_ps3_osk_test"
mkdir -p "$OUT"
cd "$ROOT"

# -DPS3_PLATFORM -include SDL.h: igual que el CMake de PS3. stubs/ trae un io/pad.h FALSO.
INC="-I. -ISexyAppFramework -ISexyAppFramework/platform -ISexyAppFramework/platform/ps3 \
 -ISexyAppFramework/platform/ps3/gl -ISexyAppFramework/platform/pc -I$HERE/stubs"
CXXFLAGS="-std=c++11 -g -O0 -fsanitize=address -fno-omit-frame-pointer -DPS3_PLATFORM -include SDL.h -w $INC"

SRCS=(
  "$HERE/osk_harness.cpp"
  SexyAppFramework/platform/ps3/Input.cpp
  SexyAppFramework/widget/VirtualKeyboard.cpp
  SexyAppFramework/widget/EditWidget.cpp
  SexyAppFramework/graphics/Font.cpp
  SexyAppFramework/widget/Insets.cpp
)
OBJS=()
for s in "${SRCS[@]}"; do
  o="$OUT/$(basename "$s" .cpp).o"
  g++ $CXXFLAGS -c "$s" -o "$o"
  OBJS+=("$o")
done
# Los stubs del framework que no se implementan quedan sin resolver a proposito (solo
# se tocarian en rutas de dibujo / otras pantallas que esta prueba no ejecuta).
g++ -fsanitize=address "${OBJS[@]}" -Wl,--unresolved-symbols=ignore-all -o "$OUT/osk_test"
"$OUT/osk_test"
