#pragma once
// ATENCION: NO es el header de PSL1GHT. Es una aproximacion hecha a mano SOLO para
// que Input.cpp compile en PC y se pueda probar la logica. Los nombres de campos
// (BTN_*, ANA_L_H/V, len, status, MAX_PADS) son los que usa Input.cpp desde la
// Parte 4; si el header real los llama distinto, el error va a aparecer al
// compilar con el toolchain de verdad.
#include <stdint.h>
#define MAX_PADS 7
typedef struct padInfo { uint32_t max; uint32_t connected; uint32_t info; uint16_t vendor_id[MAX_PADS]; uint16_t product_id[MAX_PADS]; uint8_t status[MAX_PADS]; } padInfo;
typedef struct padData {
	int len;
	unsigned BTN_LEFT:1, BTN_DOWN:1, BTN_RIGHT:1, BTN_UP:1, BTN_START:1, BTN_R3:1, BTN_L3:1, BTN_SELECT:1;
	unsigned BTN_SQUARE:1, BTN_CROSS:1, BTN_CIRCLE:1, BTN_TRIANGLE:1, BTN_R1:1, BTN_L1:1, BTN_R2:1, BTN_L2:1;
	uint16_t ANA_L_H, ANA_L_V, ANA_R_H, ANA_R_V;
} padData;
extern "C" { int ioPadInit(uint32_t); int ioPadGetInfo(padInfo*); int ioPadGetData(uint32_t, padData*); }
