#pragma once
#ifdef PS3_PLATFORM

// Teclado en pantalla con el DualShock 3.
//
// El teclado en si es el VirtualKeyboard compartido de Wii/PS2
// (SexyAppFramework/widget/VirtualKeyboard.*): lo dibuja el GL del juego y escribe
// mandando eventos de teclado normales, asi que el EditWidget del dialogo no sabe
// que existe. Este header solo traduce el pad a lo que ese teclado espera. No usa
// ninguna API de PSL1GHT (recibe el estado del pad ya leido), por eso se puede
// probar en PC.
//
// Mientras el teclado esta visible el pad es SUYO (modo teclado):
//
//   cruceta / stick izq.   mueve el foco entre teclas
//   X (cruz)               escribe la tecla enfocada
//   O (circulo)            borra
//   Triangulo              mayusculas <-> minusculas
//   START                  confirmar (igual que la tecla "Done")
//   SELECT                 pasa a modo CURSOR (ver abajo) y de vuelta
//
// Modo cursor: el pad vuelve a manejar el cursor como siempre (stick, X = click).
// Existe porque ESC enviado al campo de texto no llega al dialogo, asi que "Cancelar"
// (y cualquier otro boton del dialogo) solo se alcanza con el cursor. El teclado
// sigue en pantalla y se puede clickear. SELECT otra vez vuelve al modo teclado.

#include <cmath>

#include "widget/VirtualKeyboard.h"

namespace Ps3Osk
{

// Estado ya leido del pad (el mismo que usa Input.cpp para el juego).
struct PadButtons
{
	bool cross = false, circle = false, square = false, triangle = false;
	bool start = false, select = false;
	bool up = false, down = false, left = false, right = false;
	bool l2 = false, r2 = false;
	float lx = 0.0f, ly = 0.0f;   // -1..1, +y hacia abajo
};

// Histeresis del stick: para empezar a contar como "direccion pulsada" tiene que
// pasar kStickOn; una vez pulsada se suelta recien por debajo de kStickOff. Sin
// esto, un stick que tiembla alrededor del umbral repetiria pasos sueltos.
const float kStickOn  = 0.55f;
const float kStickOff = 0.35f;

// Stick -> UNA direccion (la del eje dominante): el teclado interpreta varios bits a
// la vez como pasos en ambos ejes, y con un stick las diagonales son inevitables.
// prevBits = lo que devolvio la llamada anterior (para la histeresis).
inline unsigned StickToNavBits(float lx, float ly, unsigned prevBits)
{
	const float ax = std::fabs(lx);
	const float ay = std::fabs(ly);

	unsigned bit;
	float mag;
	if (ax >= ay)
	{
		bit = lx < 0.0f ? (unsigned)Sexy::VKNAV_LEFT : (unsigned)Sexy::VKNAV_RIGHT;
		mag = ax;
	}
	else
	{
		bit = ly < 0.0f ? (unsigned)Sexy::VKNAV_UP : (unsigned)Sexy::VKNAV_DOWN;
		mag = ay;
	}

	const float aThreshold = (prevBits & bit) ? kStickOff : kStickOn;
	return mag >= aThreshold ? bit : 0u;
}

struct StepResult
{
	bool ownsPad;         // true: el teclado se quedo con el pad este frame, Input.cpp
	                      // no debe mover el cursor ni mandar clicks/teclas del juego
	bool cursorVisible;   // false: ocultar el cursor (en modo teclado no se usa)
};

class PadKeyboardMapper
{
public:
	PadKeyboardMapper()
		: mWasActive(false), mPointerMode(false), mArmed(false), mStickBits(0) {}

	// Una vez por frame. theKeyboardActive = VirtualKeyboardIsActive().
	StepResult Step(bool theKeyboardActive, const PadButtons& now, const PadButtons& prev)
	{
		if (theKeyboardActive != mWasActive)
		{
			// El teclado acaba de aparecer o desaparecer: arranca limpio en modo
			// teclado. mArmed = false ignora los botones de accion que ya estuvieran
			// apretados (p.ej. el X con el que se abrio el dialogo) hasta que se
			// suelten, para que no escriban una tecla sin querer.
			mWasActive = theKeyboardActive;
			mPointerMode = false;
			mArmed = false;
			mStickBits = 0;
		}

		StepResult aResult;
		aResult.ownsPad = false;
		aResult.cursorVisible = true;
		if (!theKeyboardActive)
			return aResult;

		if (now.select && !prev.select)
		{
			mPointerMode = !mPointerMode;
			mArmed = false;
			mStickBits = 0;
			if (mPointerMode)
			{
				Sexy::VirtualKeyboardFeedNav(0);          // suelta lo que hubiera apretado
				Sexy::VirtualKeyboardSetNavMode(false);   // sin foco de teclas: manda el cursor
			}
		}

		if (mPointerMode)
			return aResult;

		if (!mArmed && !AnyActionHeld(now))
			mArmed = true;

		// Idempotente. Si algo (un MouseMove que cayo sobre el teclado) lo habia
		// devuelto a modo puntero, vuelve a modo teclas sin saltar de tecla.
		Sexy::VirtualKeyboardSetNavMode(true);
		Sexy::VirtualKeyboardFeedNav(BuildNavBits(now, mArmed));

		aResult.ownsPad = true;
		aResult.cursorVisible = false;
		return aResult;
	}

	bool InPointerMode() const { return mPointerMode; }

private:
	bool mWasActive;
	bool mPointerMode;
	bool mArmed;
	unsigned mStickBits;

	static bool AnyActionHeld(const PadButtons& p)
	{
		return p.cross || p.circle || p.triangle || p.start;
	}

	unsigned BuildNavBits(const PadButtons& p, bool theArmed)
	{
		mStickBits = StickToNavBits(p.lx, p.ly, mStickBits);
		unsigned aBits = mStickBits;
		if (p.left)  aBits |= Sexy::VKNAV_LEFT;
		if (p.right) aBits |= Sexy::VKNAV_RIGHT;
		if (p.up)    aBits |= Sexy::VKNAV_UP;
		if (p.down)  aBits |= Sexy::VKNAV_DOWN;
		if (theArmed)
		{
			if (p.cross)    aBits |= Sexy::VKNAV_ACCEPT;
			if (p.circle)   aBits |= Sexy::VKNAV_BACK;
			if (p.triangle) aBits |= Sexy::VKNAV_SHIFT;
			if (p.start)    aBits |= Sexy::VKNAV_DONE;
		}
		return aBits;
	}
};

} // namespace Ps3Osk

#endif // PS3_PLATFORM
