#ifdef PS3_PLATFORM

#include <exception>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <unistd.h>

#include "LawnApp.h"
#include "Resources.h"
#include "Sexy.TodLib/TodStringFile.h"

using namespace Sexy;

bool (*gAppCloseRequest)() = nullptr;
bool (*gAppHasUsedCheatKeys)() = nullptr;
SexyString (*gGetCurrentLevelName)() = nullptr;

static void PvZPs3Terminate()
{
	printf("[PS3][FATAL] std::terminate\n");
	std::abort();
}

// Busca la carpeta con los datos (main.pak + properties/). Orden: junto al
// EBOOT, luego USB (para probar sin instalar), luego el HDD.
//   /dev_hdd0/game/<TITLEID>/USRDIR/   instalado
//   /dev_usb000/PVZ/, /dev_usb001/PVZ/ pendrive (carpeta PVZ con main.pak)
static bool Ps3HasPak(const std::string& theDir)
{
	const std::string aFile = theDir + "/main.pak";
	FILE* f = fopen(aFile.c_str(), "rb");
	if (f == nullptr)
		return false;
	fclose(f);
	return true;
}

static std::string Ps3AppDir(const char* argv0)
{
	std::string aExeDir = "/dev_hdd0/game/PVZPS3001/USRDIR";
	std::string aPath = (argv0 != nullptr) ? argv0 : "";
	const size_t aSlash = aPath.find_last_of('/');
	if (aSlash != std::string::npos)
		aExeDir = aPath.substr(0, aSlash);

	const char* aCandidates[] = {
		nullptr,                              // = carpeta del EBOOT
		"/dev_usb000/PVZ", "/dev_usb001/PVZ",
		"/dev_hdd0/game/PVZPS3001/USRDIR",
		"/dev_hdd0/PVZ",
	};
	for (const char* c : aCandidates)
	{
		const std::string aDir = (c != nullptr) ? std::string(c) : aExeDir;
		if (Ps3HasPak(aDir))
			return aDir;
	}
	printf("[PS3][WARN] main.pak no esta en ninguna ruta conocida; uso %s\n", aExeDir.c_str());
	return aExeDir;
}

int main(int argc, char** argv)
{
	(void)argc;
	std::set_terminate(PvZPs3Terminate);
	printf("[PS3] pvz_ps3 main entered (built " __DATE__ " " __TIME__ ")\n");

	const std::string aDir = Ps3AppDir(argc > 0 ? argv[0] : nullptr);
	if (chdir(aDir.c_str()) != 0)
	{
		printf("[PS3][FATAL] cannot chdir to %s\n", aDir.c_str());
		return 1;
	}
	printf("[PS3] cwd = %s\n", aDir.c_str());

	TodStringListSetColors(gLawnStringFormats, gLawnStringFormatCount);
	gGetCurrentLevelName = LawnGetCurrentLevelName;
	gAppCloseRequest = LawnGetCloseRequest;
	gAppHasUsedCheatKeys = LawnHasUsedCheatKeys;
	gExtractResourcesByName = Sexy::ExtractResourcesByName;

	try
	{
		printf("[PS3] crear LawnApp\n");
		gLawnApp = new LawnApp();
		printf("[PS3] LawnApp::Init (ventana, graficos, audio, recursos)\n");
		gLawnApp->Init();
		printf("[PS3] LawnApp::Start (bucle principal)\n");
		gLawnApp->Start();
		printf("[PS3] LawnApp::Shutdown\n");
		gLawnApp->Shutdown();
		delete gLawnApp;
		gLawnApp = nullptr;
	}
	catch (const std::bad_alloc&)
	{
		printf("[PS3][FATAL] std::bad_alloc\n");
		return 1;
	}
	catch (const std::exception& e)
	{
		printf("[PS3][FATAL] %s\n", e.what());
		return 1;
	}
	catch (...)
	{
		printf("[PS3][FATAL] unknown exception\n");
		return 1;
	}

	printf("[PS3] clean shutdown\n");
	return 0;
}

#endif
