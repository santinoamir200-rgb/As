#ifdef PS3_PLATFORM

#include <cmath>
#include <cstdint>

#include <io/pad.h>

#include "SexyAppBase.h"
#include "misc/KeyCodes.h"
#include "widget/WidgetManager.h"
#include "widget/VirtualKeyboard.h"
#include "ps3/gl/ps3gl.h"
#include "Ps3PadKeyboard.h"

using namespace Sexy;

// PARTE 4: DualShock 3 -> puntero + teclas del juego.
//
//   Stick izq / cruceta   mueve el cursor        L2 = cursor lento, R2 = rapido
//   X (cruz)              click izquierdo        (plantar, recoger soles, botones)
//   O (circulo)           click derecho          (cancelar la planta/pala en mano)
//   Cuadrado              ESPACIO                (pausa en partida)
//   Triangulo             ENTER                  (confirmar / saltar escenas)
//   START                 ESC                    (menu de pausa)
//   Boton PS              lo maneja el XMB (ps3gl_exit_requested -> Shutdown)
//
// Con el teclado en pantalla visible (dialogo de nombre del perfil) el pad cambia de
// mapa: ver Ps3PadKeyboard.h (cruceta/stick = foco, X escribe, O borra, Triangulo =
// mayusculas, START = confirmar, SELECT = cursor <-> teclado).
//
// El cursor vive en coordenadas del juego (mWidth x mHeight) y se dibuja por
// software dentro de ps3gl (ps3gl_set_cursor).

namespace
{

using PadState = Ps3Osk::PadButtons;   // lo comparte el mapeador del teclado

PadState gPad;            // ultimo estado leido (se conserva si no hay datos nuevos)
PadState gPrev;           // estado del frame anterior, para detectar flancos
Ps3Osk::PadKeyboardMapper gOsk;   // pad -> teclado en pantalla
bool     gStarted  = false;
float    gCurX     = 0.0f;
float    gCurY     = 0.0f;
uint32_t gLastTick = 0;

constexpr float kDeadZone  = 0.20f;
constexpr float kBaseSpeed = 520.0f;   // pixeles de juego por segundo (800x600)
constexpr float kSlowMul   = 0.35f;
constexpr float kFastMul   = 1.8f;

float StickAxis(unsigned v) { return ((float)v - 128.0f) / 128.0f; }

// Lee el primer pad conectado. Devuelve false si no hay pad. Si el pad no tiene
// datos nuevos (len == 0) deja gPad como estaba para no inventar soltados.
bool PollPad()
{
	padInfo info;
	if (ioPadGetInfo(&info) != 0)
		return false;

	for (int i = 0; i < MAX_PADS; ++i)
	{
		if (!info.status[i])
			continue;

		padData d;
		if (ioPadGetData(i, &d) != 0)
			return false;
		if (d.len == 0)
			return true;

		PadState s;
		s.cross    = d.BTN_CROSS    != 0;
		s.circle   = d.BTN_CIRCLE   != 0;
		s.square   = d.BTN_SQUARE   != 0;
		s.triangle = d.BTN_TRIANGLE != 0;
		s.start    = d.BTN_START    != 0;
		s.select   = d.BTN_SELECT   != 0;
		s.up       = d.BTN_UP       != 0;
		s.down     = d.BTN_DOWN     != 0;
		s.left     = d.BTN_LEFT     != 0;
		s.right    = d.BTN_RIGHT    != 0;
		s.l2       = d.BTN_L2       != 0;
		s.r2       = d.BTN_R2       != 0;
		s.lx       = StickAxis(d.ANA_L_H);
		s.ly       = StickAxis(d.ANA_L_V);
		gPad = s;
		return true;
	}
	return false;
}

inline void SendKey(WidgetManager* wm, KeyCode k, bool down)
{
	if (down) wm->KeyDown(k);
	else      wm->KeyUp(k);
}

} // namespace

void SexyAppBase::InitInput()
{
	ioPadInit(7);
	mMouseIn = true;
}

// Teclado en pantalla: se reusa el VirtualKeyboard compartido de Wii/PS2 (dibujado
// con el GL del juego, sin API de sistema). EditWidget llama a StartTextInput al
// recibir el foco y a StopTextInput al perderlo, asi que aparece solo cuando hay un
// campo de texto listo, en cualquier pantalla. Devuelve false a proposito: escribe
// en vivo con eventos de teclado normales en vez de devolver un string armado, y el
// campo tiene que conservar el texto que ya tenia.
bool SexyAppBase::StartTextInput(std::string&)
{
	return VirtualKeyboardShow(this);
}

void SexyAppBase::StopTextInput()
{
	VirtualKeyboardHide(this);
}

bool SexyAppBase::ProcessDeferredMessages(bool)
{
	// Mismo contrato que Wii: false = ya se vaciaron los eventos pendientes.
	if (ps3gl_exit_requested())
	{
		Shutdown();
		return false;
	}
	if (!mWidgetManager)
		return false;

	if (!gStarted)
	{
		gCurX = mWidth * 0.5f;
		gCurY = mHeight * 0.5f;
		gLastTick = SDL_GetTicks();
		gStarted = true;
	}

	const bool havePad = PollPad();

	// Teclado en pantalla: si esta visible y en modo teclado, se queda con el pad y
	// el cursor se oculta (no se usa). Ver Ps3PadKeyboard.h.
	Ps3Osk::StepResult osk;
	osk.ownsPad = false;
	osk.cursorVisible = true;
	if (havePad && mActive)
		osk = gOsk.Step(VirtualKeyboardIsActive(), gPad, gPrev);

	ps3gl_set_cursor(gCurX / (float)mWidth, gCurY / (float)mHeight, havePad && osk.cursorVisible);
	if (!havePad || !mActive)
		return false;

	// begin_frame limpia el back buffer en cada frame y el cursor se dibuja encima
	// del frame ya compuesto: hay que repintar todo cada vez (igual que el Wii).
	mWidgetManager->MarkAllDirty();

	if (osk.ownsPad)
	{
		// Se actualiza gPrev igual: al cerrarse el teclado, un boton que siga
		// apretado (p.ej. START, que confirma) no se tiene que ver como pulsacion
		// nueva en el mapa normal.
		gPrev = gPad;
		return false;
	}

	// --- movimiento -------------------------------------------------------
	const uint32_t now = SDL_GetTicks();
	float dt = (float)(now - gLastTick) / 1000.0f;
	gLastTick = now;
	if (dt > 0.05f) dt = 0.05f;

	float vx = gPad.lx, vy = gPad.ly;
	const float mag = std::sqrt(vx * vx + vy * vy);
	if (mag < kDeadZone)
	{
		vx = vy = 0.0f;
	}
	else
	{
		float scale = (mag - kDeadZone) / (1.0f - kDeadZone);
		if (scale > 1.0f) scale = 1.0f;
		scale = scale * scale / mag;     // curva cuadratica: fino cerca del centro
		vx *= scale;
		vy *= scale;
	}
	if (gPad.left)  vx -= 1.0f;
	if (gPad.right) vx += 1.0f;
	if (gPad.up)    vy -= 1.0f;
	if (gPad.down)  vy += 1.0f;

	float speed = kBaseSpeed;
	if (gPad.l2)      speed *= kSlowMul;
	else if (gPad.r2) speed *= kFastMul;

	const float oldX = gCurX, oldY = gCurY;
	gCurX += vx * speed * dt;
	gCurY += vy * speed * dt;
	if (gCurX < 0.0f) gCurX = 0.0f;
	if (gCurY < 0.0f) gCurY = 0.0f;
	if (gCurX > (float)(mWidth - 1))  gCurX = (float)(mWidth - 1);
	if (gCurY > (float)(mHeight - 1)) gCurY = (float)(mHeight - 1);

	const int x = (int)gCurX, y = (int)gCurY;
	if ((int)oldX != x || (int)oldY != y)
		mWidgetManager->MouseMove(x, y);

	// --- botones (flancos) ----------------------------------------------
	if (gPad.cross != gPrev.cross)
	{
		if (gPad.cross) mWidgetManager->MouseDown(x, y, 1);
		else            mWidgetManager->MouseUp(x, y, 1);
	}
	if (gPad.circle != gPrev.circle)
	{
		if (gPad.circle) mWidgetManager->MouseDown(x, y, -1);
		else             mWidgetManager->MouseUp(x, y, -1);
	}
	if (gPad.square != gPrev.square)     SendKey(mWidgetManager, KeyCode::KEYCODE_SPACE,  gPad.square);
	if (gPad.triangle != gPrev.triangle) SendKey(mWidgetManager, KeyCode::KEYCODE_RETURN, gPad.triangle);
	if (gPad.start != gPrev.start)       SendKey(mWidgetManager, KeyCode::KEYCODE_ESCAPE, gPad.start);

	gPrev = gPad;
	return false;
}

#endif
