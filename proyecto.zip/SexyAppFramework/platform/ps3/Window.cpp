#ifdef PS3_PLATFORM

#include "SexyAppBase.h"
#include "graphics/GLInterface.h"
#include "graphics/GLImage.h"
#include "widget/WidgetManager.h"
#include "ps3/gl/ps3gl.h"

using namespace Sexy;

// Equivale a platform/wii/Window.cpp: en consola no hay ventana real, solo se
// inicializa el display y se crea el GLInterface del juego.
void SexyAppBase::MakeWindow()
{
	printf("[PS3] MakeWindow: inicio\n");
	if (!mWindow)
	{
		if (!ps3gl_init())
		{
			printf("[PS3][FATAL] ps3gl_init fallo; sin pantalla\n");
			return;
		}
		mWindow = reinterpret_cast<void*>(1);
		mContext = reinterpret_cast<void*>(1);
	}

	if (!mGLInterface)
	{
		mGLInterface = new GLInterface(this);
		InitGLInterface();
	}

	mActive = true;
	mMinimized = false;
	mPhysMinimized = false;
	ReInitImages();

	mWidgetManager->mImage = mGLInterface->GetScreenImage();
	mWidgetManager->MarkAllDirty();
	mGLInterface->UpdateViewport();
	mWidgetManager->Resize(mScreenBounds, mGLInterface->mPresentationRect);
	printf("[PS3] MakeWindow: listo\n");
}

#endif
