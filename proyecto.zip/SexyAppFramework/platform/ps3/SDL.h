#pragma once
// Shim minimo de SDL para PS3 (igual que platform/wii/SDL.h). El juego llega
// aca por "-include SDL.h" en las compilaciones de consola.
#ifdef PS3_PLATFORM

#include <stdint.h>
#include <unistd.h>
#include <time.h>

typedef uint32_t Uint32;
typedef uint64_t Uint64;

#define SDL_INIT_TIMER 0x00000001u
#define SDL_QUIT       0x100u

typedef struct SDL_QuitEvent { Uint32 type; Uint32 timestamp; } SDL_QuitEvent;
typedef union SDL_Event { Uint32 type; SDL_QuitEvent quit; } SDL_Event;

static inline int SDL_Init(Uint32) { return 0; }

static inline Uint64 ps3_now_ns()
{
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return (Uint64)ts.tv_sec * 1000000000ull + (Uint64)ts.tv_nsec;
}
static inline Uint32 SDL_GetTicks() { return (Uint32)(ps3_now_ns() / 1000000ull); }
static inline void   SDL_Delay(Uint32 ms) { usleep((useconds_t)ms * 1000u); }
static inline Uint64 SDL_GetPerformanceCounter() { return ps3_now_ns(); }
static inline Uint64 SDL_GetPerformanceFrequency() { return 1000000000ull; }
static inline int    SDL_PushEvent(SDL_Event*) { return 0; }

#endif
