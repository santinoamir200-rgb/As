#pragma once
// Shim minimo de SDL para PS3 (igual que platform/wii/SDL.h). El juego llega
// aca por "-include SDL.h" en las compilaciones de consola.
#ifdef PS3_PLATFORM

// Este header se fuerza con "-include SDL.h" ANTES de todo el codigo del juego, asi que
// tambien tiene que traer los tipos/headers que el newlib de PSL1GHT no arrastra solo
// (Common.h usa va_list y ulong sin incluir nada).
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>

#ifndef _ULONG_DEFINED_BY_PS3_SHIM
#define _ULONG_DEFINED_BY_PS3_SHIM
#ifndef ulong
typedef unsigned long ulong;
#endif
#endif

// --- libc que el newlib de PSL1GHT no trae / trae distinto -------------------------------
// nanosleep: SexyAppBase.cpp lo usa y el newlib de PSL1GHT no lo declara. Se redirige a
// usleep (que si existe) con una funcion propia, sin tocar el codigo del juego.
static inline int ps3_nanosleep(const struct timespec* req, struct timespec* rem)
{
	if (req) usleep((unsigned int)(req->tv_sec * 1000000L + req->tv_nsec / 1000L));
	if (rem) { rem->tv_sec = 0; rem->tv_nsec = 0; }
	return 0;
}
#define nanosleep ps3_nanosleep

// pthread_self: en PSL1GHT (pthread-embedded) pthread_t es un struct (pte_handle_t), no un
// entero, y el juego hace (void*)pthread_self(). Se devuelve el puntero interno del handle,
// que identifica al hilo igual que el entero en otras plataformas.
// El <pthread.h> de PSL1GHT (pthread-embedded) NO trae extern "C": en C++ el linker buscaba
// _Z18pthread_mutex_lockPP16pthread_mutex_t_ en vez de pthread_mutex_lock. Como este header se
// fuerza antes que cualquier otro, incluirlo aca dentro de extern "C" fija el enlace C para todo
// el proyecto (el include guard evita que se vuelva a incluir sin extern "C").
#ifdef __cplusplus
extern "C" {
#endif
#include <pthread.h>
#ifdef __cplusplus
}
#endif
static inline void* ps3_pthread_self_id()
{
	pthread_t t = pthread_self();
	return (void*)t.p;
}
#define pthread_self() ps3_pthread_self_id()

typedef uint32_t Uint32;
typedef uint64_t Uint64;

#define SDL_INIT_TIMER 0x00000001u
#define SDL_QUIT       0x100u

typedef struct SDL_QuitEvent { Uint32 type; Uint32 timestamp; } SDL_QuitEvent;
typedef union SDL_Event { Uint32 type; SDL_QuitEvent quit; } SDL_Event;

static inline int SDL_Init(Uint32) { return 0; }

// El newlib de PSL1GHT no declara clock_gettime/CLOCK_MONOTONIC. En la PPU leemos el
// timebase directo (mftb): 79.8 MHz en la PS3, sin depender de ningun header.
#define PS3_TIMEBASE_HZ 79800000ull

static inline Uint64 ps3_now_ns()
{
#if defined(__powerpc__) || defined(__PPC__) || defined(__powerpc64__)
	uint64_t tb;
	__asm__ volatile("mftb %0" : "=r"(tb));
	// tb * 1e9 / 79.8e6 = tb * 10000 / 798, partido para no desbordar 64 bits
	return (Uint64)(tb / 798ull) * 10000ull + (Uint64)((tb % 798ull) * 10000ull) / 798ull;
#else
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return (Uint64)ts.tv_sec * 1000000000ull + (Uint64)ts.tv_nsec;
#endif
}
static inline Uint32 SDL_GetTicks() { return (Uint32)(ps3_now_ns() / 1000000ull); }
static inline void   SDL_Delay(Uint32 ms) { usleep((unsigned int)ms * 1000u); }
static inline Uint64 SDL_GetPerformanceCounter() { return ps3_now_ns(); }
static inline Uint64 SDL_GetPerformanceFrequency() { return 1000000000ull; }
static inline int    SDL_PushEvent(SDL_Event*) { return 0; }

#endif
