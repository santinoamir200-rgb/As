#pragma once
// PARTE 5: audio real para PS3.
//
// Arquitectura (ver Ps3Audio.cpp):
//   * libaudio de PSL1GHT, un puerto estereo de 8 bloques x 256 muestras float,
//     48 kHz fijos (el hardware no acepta otra tasa).
//   * Un hilo mezclador propio: espera el evento de "bloque consumido", mezcla
//     todas las voces de efectos + el stream de musica y escribe el bloque.
//   * Efectos: se decodifican enteros a PCM 16 bit (OGG o WAV, via PakInterface,
//     igual que el Wii) y se remuestrean con interpolacion lineal al mezclar.
//   * Musica: el OGG comprimido queda en RAM y se decodifica de a trozos en el
//     hilo mezclador (stb_vorbis, el mismo vendored que usan PS2/Wii).
//
// Los nombres Ps3Music* son los que usa Lawn/System/Music.cpp (StreamMusic*).
#ifdef PS3_PLATFORM

#include "sound/SoundManager.h"
#include "sound/SoundInstance.h"
#include "sound/MusicInterface.h"
#include <list>
#include <string>

namespace Sexy
{

class Ps3SoundManager;

// PCM 16 bit big-endian (endian nativo del PPU), contado por referencias: una
// voz activa retiene su muestra aunque el manager la purgue (PurgeSounds).
struct Ps3Sample
{
	volatile int	mRef;
	short*			mPCM;
	int				mFrames;
	int				mRate;
	int				mChannels;		// 1 o 2
	Ps3Sample() : mRef(1), mPCM(0), mFrames(0), mRate(0), mChannels(0) {}
};

class Ps3SoundInstance : public SoundInstance
{
public:
	Ps3SoundManager*	mManager;
	int					mSfxID;
	int					mVoice;			// -1 si no suena
	unsigned int		mSerial;		// serial de la voz que arranco esta instancia
	double				mBaseVolume;
	double				mVolume;
	int					mBasePan;
	int					mPan;
	double				mPitchRatio;
	bool				mReleased;
	bool				mAutoRelease;

	Ps3SoundInstance(Ps3SoundManager* theManager, int theSfxID);

	// Los *Locked asumen el spinlock del mixer tomado (no es recursivo).
	bool				VoiceAliveLocked();
	void				ApplyVolumeLocked();
	void				ApplyVolume();

	virtual void		Release();
	virtual void		SetBaseVolume(double theBaseVolume);
	virtual void		SetBasePan(int theBasePan);
	virtual void		AdjustPitch(double theNumSteps);
	virtual void		SetVolume(double theVolume);
	virtual void		SetPan(int thePosition);
	virtual bool		Play(bool looping, bool autoRelease);
	virtual void		Stop();
	virtual bool		IsPlaying();
	virtual bool		IsReleased();
	virtual double		GetVolume();
};

class Ps3SoundManager : public SoundManager
{
public:
	bool				mInitialized;
	Ps3Sample*			mSamples[MAX_SOURCE_SOUNDS];
	std::string			mSourceFileNames[MAX_SOURCE_SOUNDS];
	double				mBaseVolumes[MAX_SOURCE_SOUNDS];
	int					mBasePans[MAX_SOURCE_SOUNDS];
	double				mMasterVolume;
	std::list<Ps3SoundInstance*>	mInstances;

	Ps3SoundManager();
	virtual ~Ps3SoundManager();

	void				ReapDeadInstancesLocked();
	bool				EnsureSampleLoaded(unsigned int theSfxID);
	void				FreeSampleLocked(unsigned int theSfxID);

	virtual bool		Initialized();
	virtual bool		LoadSound(unsigned int theSfxID, const std::string& theFilename);
	virtual int			LoadSound(const std::string& theFilename);
	virtual void		ReleaseSound(unsigned int theSfxID);
	virtual void		SetVolume(double theVolume);
	virtual bool		SetBaseVolume(unsigned int theSfxID, double theBaseVolume);
	virtual bool		SetBasePan(unsigned int theSfxID, int theBasePan);
	virtual SoundInstance* GetSoundInstance(unsigned int theSfxID);
	virtual void		ReleaseSounds();
	virtual void		ReleaseChannels();
	virtual double		GetMasterVolume();
	virtual void		SetMasterVolume(double theVolume);
	virtual void		Flush();
	virtual void		SetCooperativeWindow(HWND theHWnd);
	virtual void		StopAllSounds();
	virtual int			GetFreeSoundId();
	virtual int			GetNumSounds();
	virtual void		PurgeSounds();
	virtual void		PreloadSound(unsigned int theSfxID);
};

// Misma logica que WiiMusicInterface: Music.cpp abre el OGG y llama a
// Ps3MusicPlay; esto solo recuerda el id de la cancion y reenvia el volumen
// maestro del slider de opciones. No hace falta Update(): el hilo mezclador
// decodifica solo.
class Ps3MusicInterface : public MusicInterface
{
public:
	Ps3MusicInterface();
	virtual ~Ps3MusicInterface();

	virtual bool		LoadMusic(int theSongId, const std::string& theFileName);
	virtual void		PlayMusic(int theSongId, int theOffset = 0, bool noLoop = false);
	virtual void		StopMusic(int theSongId);
	virtual void		PauseMusic(int theSongId);
	virtual void		ResumeMusic(int theSongId);
	virtual void		StopAllMusic();
	virtual void		UnloadMusic(int theSongId);
	virtual void		UnloadAllMusic();
	virtual void		PauseAllMusic();
	virtual void		ResumeAllMusic();
	virtual void		FadeIn(int theSongId, int theOffset = -1, double theSpeed = 0.002, bool noLoop = false);
	virtual void		FadeOut(int theSongId, bool stopSong = true, double theSpeed = 0.004);
	virtual void		FadeOutAll(bool stopSong = true, double theSpeed = 0.004);
	virtual void		SetSongVolume(int theSongId, double theVolume);
	virtual void		SetSongMaxVolume(int theSongId, double theMaxVolume);
	virtual bool		IsPlaying(int theSongId);
	virtual void		SetVolume(double theVolume);
	virtual void		SetMusicAmplify(int theSongId, double theAmp);
	virtual void		Update();
};

// Arranca libaudio y el hilo mezclador (idempotente). false si fallo: en ese
// caso todo lo demas queda mudo pero no revienta.
bool Ps3AudioInit();
void Ps3AudioShutdown();

// Prueba de arranque en hardware/RPCS3: un tono de 440 Hz durante ~0.4 s.
// No bloquea. Llamarlo una vez despues de crear el SoundManager (p. ej. desde
// pvz_ps3_main.cpp) mientras se verifica que libaudio anda; sacarlo despues.
bool Ps3AudioBeep();

// Streaming de musica. Ps3MusicPlay toma posesion de theOggData (malloc'd) y
// lo libera al parar o si falla.
bool Ps3MusicPlay(unsigned char* theOggData, int theSize, bool theLoop);
void Ps3MusicStop();
void Ps3MusicSetPaused(bool thePaused);
bool Ps3MusicIsPlaying();
void Ps3MusicSetVolume(double theVolume);			// por cancion (fades), 0..1
void Ps3MusicSetMasterVolume(double theVolume);		// slider de opciones, 0..1

}
#endif // PS3_PLATFORM
