#ifdef PS3_PLATFORM
// ============================================================================
// Audio PS3 (Parte 5). Ver Ps3Sound.h para el esquema general.
//
// TODO lo que toca la API de PSL1GHT (audio*, sysThread*, sysEventQueue*) esta
// concentrado en la seccion "OS / libaudio" de abajo. Si algun nombre o firma
// no coincide con tus headers, el error de compilacion cae ahi y el resto del
// archivo (mezcla, decodificacion, API del juego) no se entera.
// ============================================================================

#include "Ps3Sound.h"
#include "paklib/PakInterface.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>

// ---- PSL1GHT (SIN VERIFICAR contra los headers reales, ver README_PS3.md) ----
#include <ppu-types.h>
#include <audio/audio.h>
#include <sys/thread.h>
#include <sys/event_queue.h>

// Plain stb_vorbis, el mismo vendored que usan PS2 y Wii. La implementacion se
// incluye AQUI y solo aqui.
#define STB_VORBIS_NO_STDIO
#define STB_VORBIS_MAX_CHANNELS 2
#include "../../../sound/SDL-Mixer-X/src/codecs/stb_vorbis/stb_vorbis.h"

using namespace Sexy;

// ---------------------------------------------------------------------------
// Parametros
// ---------------------------------------------------------------------------
#ifndef AUDIO_BLOCK_SAMPLES
#define AUDIO_BLOCK_SAMPLES		256			// fijo en libaudio de la PS3
#endif
#define PS3_OUT_RATE			48000		// fijo en libaudio de la PS3
#define PS3_MAX_VOICES			32
#define PS3_MUS_FIFO_FRAMES		8192		// potencia de 2
#define PS3_MUS_CHUNK_FRAMES	1024

#ifndef PS3AUDIO_THREAD_PRIO
#define PS3AUDIO_THREAD_PRIO	1000		// menor = mas prioridad (el main suele ser 1001)
#endif
#ifndef PS3AUDIO_THREAD_STACK
#define PS3AUDIO_THREAD_STACK	(256 * 1024)
#endif

namespace
{

// ---------------------------------------------------------------------------
// Spinlock. No uso mutex de sys/ para no sumar otra API sin verificar: las
// secciones criticas son de microsegundos y el PPU tiene 2 hilos de hardware.
// Es NO recursivo: cada metodo publico lo toma una sola vez y todo lo de abajo
// es *Locked (misma regla que WiiSoundManager).
// ---------------------------------------------------------------------------
volatile int g_lock = 0;

inline void LockMixer()
{
	int aSpins = 0;
	while (__sync_lock_test_and_set(&g_lock, 1))
	{
		if (++aSpins > 64)
		{
			sysThreadYield();
			aSpins = 0;
		}
	}
}

inline void UnlockMixer()
{
	__sync_lock_release(&g_lock);
}

// ---------------------------------------------------------------------------
// Voces de efectos (las lee el hilo mezclador; se tocan siempre bajo el lock)
// ---------------------------------------------------------------------------
struct Ps3Voice
{
	bool			mActive;
	bool			mLoop;
	Ps3Sample*		mSample;
	double			mPos;		// en frames de la muestra
	double			mStep;		// frames de la muestra por frame de salida
	float			mVolL;
	float			mVolR;
	unsigned int	mSerial;
	unsigned int	mStamp;		// para robar la mas vieja
};

Ps3Voice		g_voices[PS3_MAX_VOICES];
unsigned int	g_serialCounter = 0;
unsigned int	g_stampCounter = 0;

void ReleaseSampleLocked(Ps3Sample* theSample)
{
	if (theSample == NULL)
		return;
	if (--theSample->mRef <= 0)
	{
		free(theSample->mPCM);
		delete theSample;
	}
}

void ReleaseVoiceLocked(int theVoice)
{
	Ps3Voice& aVoice = g_voices[theVoice];
	if (!aVoice.mActive)
		return;
	aVoice.mActive = false;
	ReleaseSampleLocked(aVoice.mSample);
	aVoice.mSample = NULL;
}

// ---------------------------------------------------------------------------
// Musica (estado del stream: lo toca SOLO el hilo mezclador, salvo los
// escalares volatile y el buzon "pending", que se protege con el lock)
// ---------------------------------------------------------------------------
struct MusicPending
{
	bool			mStop;
	bool			mHasNew;
	stb_vorbis*		mVorbis;
	unsigned char*	mData;
	int				mRate;
	bool			mLoop;
	MusicPending() : mStop(false), mHasNew(false), mVorbis(NULL), mData(NULL), mRate(0), mLoop(false) {}
};

MusicPending	g_musPending;

// estado activo (solo hilo mezclador)
stb_vorbis*		g_musVorbis = NULL;
unsigned char*	g_musData = NULL;
int				g_musRate = 44100;
bool			g_musLoop = false;
bool			g_musEnded = false;			// el decoder ya no da mas datos
short			g_musFifo[PS3_MUS_FIFO_FRAMES * 2];
int				g_musHead = 0;				// indice de frame
int				g_musCount = 0;				// frames validos en el fifo
double			g_musSrcPos = 0.0;			// posicion fraccional desde g_musHead

// escalares compartidos (escritura atomica de 32 bit)
volatile int	g_musPlaying = 0;
volatile int	g_musPaused = 0;
volatile float	g_musVolume = 1.0f;			// por cancion (fades)
volatile float	g_musMaster = 1.0f;			// slider de opciones

void FreeMusicResources(stb_vorbis* theVorbis, unsigned char* theData)
{
	if (theVorbis != NULL)
		stb_vorbis_close(theVorbis);
	free(theData);
}

// ---------------------------------------------------------------------------
// OS / libaudio  (SIN VERIFICAR contra headers reales)
// ---------------------------------------------------------------------------
bool				g_audioUp = false;			// libaudio + hilo listos
volatile int		g_quit = 0;
u32					g_port = 0;
float*				g_portBuf = NULL;			// audioDataStart
int					g_numBlocks = 8;
int					g_writeBlock = 0;
sys_event_queue_t	g_queue = 0;
sys_ipc_key_t		g_queueKey = 0;
sys_ppu_thread_t	g_thread = 0;
bool				g_threadStarted = false;
bool				g_portOpen = false;
bool				g_audioInitDone = false;
bool				g_notifySet = false;

float				g_mix[AUDIO_BLOCK_SAMPLES * 2];

// Escribe el pan como en Wii/PS2: centesimas de dB, negativo = izquierda, y
// atenua el canal lejano.
void ApplyPan(double theVolume, int thePan, float& theL, float& theR)
{
	double aL = theVolume, aR = theVolume;
	if (thePan < 0)
		aR *= pow(10.0, thePan / 2000.0);
	else if (thePan > 0)
		aL *= pow(10.0, -thePan / 2000.0);
	if (aL < 0.0) aL = 0.0;
	if (aL > 1.0) aL = 1.0;
	if (aR < 0.0) aR = 0.0;
	if (aR > 1.0) aR = 1.0;
	theL = (float)aL;
	theR = (float)aR;
}

// ---- Mezcla de efectos: llamar con el lock tomado ----
void MixVoicesLocked()
{
	const float kInv = 1.0f / 32768.0f;
	for (int v = 0; v < PS3_MAX_VOICES; v++)
	{
		Ps3Voice& aVoice = g_voices[v];
		if (!aVoice.mActive)
			continue;

		const Ps3Sample* aSmp = aVoice.mSample;
		const short* aPCM = aSmp->mPCM;
		const int aFrames = aSmp->mFrames;
		const bool aStereo = (aSmp->mChannels >= 2);
		double aPos = aVoice.mPos;
		const double aStep = aVoice.mStep;
		const float aVolL = aVoice.mVolL * kInv;
		const float aVolR = aVoice.mVolR * kInv;

		int i = 0;
		for (; i < AUDIO_BLOCK_SAMPLES; i++)
		{
			if (aPos >= (double)aFrames)
			{
				if (!aVoice.mLoop || aFrames <= 0)
					break;
				while (aPos >= (double)aFrames)
					aPos -= (double)aFrames;
			}

			const int i0 = (int)aPos;
			const float aFrac = (float)(aPos - (double)i0);
			int i1 = i0 + 1;
			if (i1 >= aFrames)
				i1 = aVoice.mLoop ? 0 : i0;

			float aSL, aSR;
			if (aStereo)
			{
				const float l0 = (float)aPCM[i0 * 2],     r0 = (float)aPCM[i0 * 2 + 1];
				const float l1 = (float)aPCM[i1 * 2],     r1 = (float)aPCM[i1 * 2 + 1];
				aSL = l0 + (l1 - l0) * aFrac;
				aSR = r0 + (r1 - r0) * aFrac;
			}
			else
			{
				const float m0 = (float)aPCM[i0], m1 = (float)aPCM[i1];
				aSL = aSR = m0 + (m1 - m0) * aFrac;
			}

			g_mix[i * 2]     += aSL * aVolL;
			g_mix[i * 2 + 1] += aSR * aVolR;
			aPos += aStep;
		}

		if (i < AUDIO_BLOCK_SAMPLES)
			ReleaseVoiceLocked(v);		// termino
		else
			aVoice.mPos = aPos;
	}
}

// ---- Musica ----

// Toma el buzon. Con el lock tomado. Devuelve lo que hay que cerrar afuera.
void AdoptMusicPendingLocked(stb_vorbis*& theOldVorbis, unsigned char*& theOldData)
{
	theOldVorbis = NULL;
	theOldData = NULL;
	if (!g_musPending.mStop && !g_musPending.mHasNew)
		return;

	theOldVorbis = g_musVorbis;
	theOldData = g_musData;
	g_musVorbis = NULL;
	g_musData = NULL;
	g_musEnded = false;
	g_musHead = 0;
	g_musCount = 0;
	g_musSrcPos = 0.0;

	if (g_musPending.mHasNew)
	{
		g_musVorbis = g_musPending.mVorbis;
		g_musData = g_musPending.mData;
		g_musRate = g_musPending.mRate;
		g_musLoop = g_musPending.mLoop;
		g_musPending.mVorbis = NULL;
		g_musPending.mData = NULL;
	}
	g_musPending.mStop = false;
	g_musPending.mHasNew = false;
}

void MusicDecodeChunk()
{
	short aTmp[PS3_MUS_CHUNK_FRAMES * 2];
	int aFrames = stb_vorbis_get_samples_short_interleaved(
		g_musVorbis, 2, aTmp, PS3_MUS_CHUNK_FRAMES * 2);
	if (aFrames <= 0)
	{
		if (g_musLoop)
		{
			stb_vorbis_seek_start(g_musVorbis);
			aFrames = stb_vorbis_get_samples_short_interleaved(
				g_musVorbis, 2, aTmp, PS3_MUS_CHUNK_FRAMES * 2);
		}
		if (aFrames <= 0)
		{
			g_musEnded = true;
			return;
		}
	}
	for (int f = 0; f < aFrames; f++)
	{
		const int aIdx = (g_musHead + g_musCount + f) & (PS3_MUS_FIFO_FRAMES - 1);
		g_musFifo[aIdx * 2]     = aTmp[f * 2];
		g_musFifo[aIdx * 2 + 1] = aTmp[f * 2 + 1];
	}
	g_musCount += aFrames;
}

// Decodifica lo que falte. Sin lock (solo toca estado del hilo mezclador).
void MusicRefill()
{
	if (g_musVorbis == NULL || g_musEnded || g_musPaused)
		return;

	int aBudget = 2;		// trozos por bloque; si el fifo esta casi vacio no hay tope
	while (!g_musEnded && g_musCount <= PS3_MUS_FIFO_FRAMES - PS3_MUS_CHUNK_FRAMES)
	{
		const bool aUrgent = g_musCount < 1024;
		if (!aUrgent && g_musCount >= PS3_MUS_FIFO_FRAMES / 2)
			break;
		if (!aUrgent && aBudget <= 0)
			break;
		MusicDecodeChunk();
		aBudget--;
	}
}

// Suma la musica a g_mix. Sin lock.
void MusicMix()
{
	if (g_musVorbis == NULL || g_musPaused)
		return;

	float aVol = g_musVolume * g_musMaster;
	if (aVol < 0.0f) aVol = 0.0f;
	if (aVol > 1.0f) aVol = 1.0f;
	aVol *= (1.0f / 32768.0f);

	const double aStep = (double)g_musRate / (double)PS3_OUT_RATE;
	double aPos = g_musSrcPos;

	for (int i = 0; i < AUDIO_BLOCK_SAMPLES; i++)
	{
		const int i0 = (int)aPos;
		if (i0 + 1 >= g_musCount)
			break;		// underrun (o fin: se resuelve abajo)
		const float aFrac = (float)(aPos - (double)i0);
		const int a = (g_musHead + i0) & (PS3_MUS_FIFO_FRAMES - 1);
		const int b = (a + 1) & (PS3_MUS_FIFO_FRAMES - 1);
		const float l0 = (float)g_musFifo[a * 2],     r0 = (float)g_musFifo[a * 2 + 1];
		const float l1 = (float)g_musFifo[b * 2],     r1 = (float)g_musFifo[b * 2 + 1];
		g_mix[i * 2]     += (l0 + (l1 - l0) * aFrac) * aVol;
		g_mix[i * 2 + 1] += (r0 + (r1 - r0) * aFrac) * aVol;
		aPos += aStep;
	}

	int aConsumed = (int)aPos;
	if (aConsumed > g_musCount)
		aConsumed = g_musCount;
	g_musHead = (g_musHead + aConsumed) & (PS3_MUS_FIFO_FRAMES - 1);
	g_musCount -= aConsumed;
	g_musSrcPos = aPos - (double)aConsumed;
}

// Fin natural de la cancion (sin loop): el fifo se vacio. Sin lock; cierra afuera
// porque solo este hilo toca g_musVorbis/g_musData.
void MusicCheckFinished()
{
	if (g_musVorbis != NULL && g_musEnded && g_musCount < 2)
	{
		FreeMusicResources(g_musVorbis, g_musData);
		g_musVorbis = NULL;
		g_musData = NULL;
		g_musEnded = false;
		g_musCount = 0;
		g_musHead = 0;
		g_musSrcPos = 0.0;
		// Solo bajar la bandera si nadie pidio otra cancion mientras tanto.
		LockMixer();
		if (!g_musPending.mHasNew)
			g_musPlaying = 0;
		UnlockMixer();
	}
}

// Un bloque completo de audio: devuelve en g_mix lo que hay que escribir.
void BuildBlock()
{
	memset(g_mix, 0, sizeof(g_mix));

	stb_vorbis* aOldVorbis = NULL;
	unsigned char* aOldData = NULL;

	LockMixer();
	AdoptMusicPendingLocked(aOldVorbis, aOldData);
	UnlockMixer();
	FreeMusicResources(aOldVorbis, aOldData);		// fuera del lock

	MusicRefill();

	LockMixer();
	MixVoicesLocked();
	UnlockMixer();

	MusicMix();
	MusicCheckFinished();

	for (int i = 0; i < AUDIO_BLOCK_SAMPLES * 2; i++)
	{
		if (g_mix[i] > 1.0f) g_mix[i] = 1.0f;
		else if (g_mix[i] < -1.0f) g_mix[i] = -1.0f;
	}
}

void MixerThreadMain(void* /*theArg*/)
{
	while (!g_quit)
	{
		sys_event_t anEvent;
		// 100 ms de timeout para poder mirar g_quit.
		const s32 aResult = sysEventQueueReceive(g_queue, &anEvent, 100 * 1000);
		if (aResult != 0)
			continue;

		BuildBlock();

		float* aDst = g_portBuf + (size_t)g_writeBlock * AUDIO_BLOCK_SAMPLES * 2;
		memcpy(aDst, g_mix, sizeof(g_mix));
		g_writeBlock = (g_writeBlock + 1) % g_numBlocks;
	}
	sysThreadExit(0);
}

} // namespace

// ===========================================================================
// Init / shutdown
// ===========================================================================

bool Sexy::Ps3AudioInit()
{
	if (g_audioUp)
		return true;

	for (int v = 0; v < PS3_MAX_VOICES; v++)
	{
		g_voices[v].mActive = false;
		g_voices[v].mSample = NULL;
	}

	if (audioInit() != 0)
	{
		printf("[PS3][SND] audioInit failed\n");
		return false;
	}
	g_audioInitDone = true;

	audioPortParam aParam;
	memset(&aParam, 0, sizeof(aParam));
	aParam.numChannels = AUDIO_PORT_2CH;
	aParam.numBlocks = AUDIO_BLOCK_8;
	aParam.attrib = 0;
	aParam.level = 1.0f;
	if (audioPortOpen(&aParam, &g_port) != 0)
	{
		printf("[PS3][SND] audioPortOpen failed\n");
		Ps3AudioShutdown();
		return false;
	}
	g_portOpen = true;

	audioPortConfig aConfig;
	memset(&aConfig, 0, sizeof(aConfig));
	if (audioGetPortConfig(g_port, &aConfig) != 0)
	{
		printf("[PS3][SND] audioGetPortConfig failed\n");
		Ps3AudioShutdown();
		return false;
	}
	g_portBuf = (float*)(uintptr_t)aConfig.audioDataStart;
	g_numBlocks = (int)aConfig.numBlocks;
	if (g_portBuf == NULL || g_numBlocks <= 0 || (int)aConfig.channelCount != 2)
	{
		printf("[PS3][SND] unexpected port config (blocks=%d ch=%d)\n",
			g_numBlocks, (int)aConfig.channelCount);
		Ps3AudioShutdown();
		return false;
	}
	memset(g_portBuf, 0, (size_t)g_numBlocks * AUDIO_BLOCK_SAMPLES * 2 * sizeof(float));
	g_writeBlock = 0;

	if (audioCreateNotifyEventQueue(&g_queue, &g_queueKey) != 0 ||
		audioSetNotifyEventQueue(g_queueKey) != 0)
	{
		printf("[PS3][SND] notify event queue failed\n");
		Ps3AudioShutdown();
		return false;
	}
	g_notifySet = true;
	sysEventQueueDrain(g_queue);

	g_quit = 0;
	if (sysThreadCreate(&g_thread, MixerThreadMain, NULL,
			PS3AUDIO_THREAD_PRIO, PS3AUDIO_THREAD_STACK, THREAD_JOINABLE, "pvz_audio") != 0)
	{
		printf("[PS3][SND] mixer thread create failed\n");
		Ps3AudioShutdown();
		return false;
	}
	g_threadStarted = true;

	if (audioPortStart(g_port) != 0)
	{
		printf("[PS3][SND] audioPortStart failed\n");
		Ps3AudioShutdown();
		return false;
	}

	g_audioUp = true;
	printf("[PS3][SND] audio up: %d blocks x %d samples @ %d Hz\n",
		g_numBlocks, AUDIO_BLOCK_SAMPLES, PS3_OUT_RATE);
	return true;
}

void Sexy::Ps3AudioShutdown()
{
	g_audioUp = false;

	if (g_threadStarted)
	{
		g_quit = 1;
		u64 aRet = 0;
		sysThreadJoin(g_thread, &aRet);
		g_threadStarted = false;
	}
	if (g_portOpen)
	{
		audioPortStop(g_port);
		if (g_notifySet)
		{
			audioRemoveNotifyEventQueue(g_queueKey);
			sysEventQueueDestroy(g_queue, 0);
			g_notifySet = false;
		}
		audioPortClose(g_port);
		g_portOpen = false;
	}
	else if (g_notifySet)
	{
		audioRemoveNotifyEventQueue(g_queueKey);
		sysEventQueueDestroy(g_queue, 0);
		g_notifySet = false;
	}
	if (g_audioInitDone)
	{
		audioQuit();
		g_audioInitDone = false;
	}

	// Ya no corre el mezclador: liberar lo que quedo colgado.
	LockMixer();
	for (int v = 0; v < PS3_MAX_VOICES; v++)
		ReleaseVoiceLocked(v);
	stb_vorbis* aPV = g_musPending.mVorbis;
	unsigned char* aPD = g_musPending.mData;
	g_musPending.mVorbis = NULL;
	g_musPending.mData = NULL;
	g_musPending.mHasNew = false;
	g_musPending.mStop = false;
	UnlockMixer();
	FreeMusicResources(aPV, aPD);
	FreeMusicResources(g_musVorbis, g_musData);
	g_musVorbis = NULL;
	g_musData = NULL;
	g_musPlaying = 0;
}

bool Sexy::Ps3AudioBeep()
{
	if (!g_audioUp)
		return false;
	const int aFrames = PS3_OUT_RATE * 2 / 5;		// 0.4 s
	short* aPCM = (short*)malloc((size_t)aFrames * sizeof(short));
	if (aPCM == NULL)
		return false;
	for (int i = 0; i < aFrames; i++)
		aPCM[i] = (short)(sin(2.0 * 3.14159265358979 * 440.0 * i / PS3_OUT_RATE) * 8000.0);

	Ps3Sample* aSample = new Ps3Sample();		// mRef = 1: la toma la voz
	aSample->mPCM = aPCM;
	aSample->mFrames = aFrames;
	aSample->mRate = PS3_OUT_RATE;
	aSample->mChannels = 1;

	LockMixer();
	int aIdx = -1;
	for (int v = 0; v < PS3_MAX_VOICES && aIdx < 0; v++)
		if (!g_voices[v].mActive)
			aIdx = v;
	if (aIdx < 0)
	{
		UnlockMixer();
		ReleaseSampleLocked(aSample);
		return false;
	}
	Ps3Voice& aVoice = g_voices[aIdx];
	aVoice.mSample = aSample;
	aVoice.mPos = 0.0;
	aVoice.mStep = 1.0;
	aVoice.mLoop = false;
	aVoice.mVolL = aVoice.mVolR = 0.5f;
	aVoice.mSerial = ++g_serialCounter;
	aVoice.mStamp = ++g_stampCounter;
	aVoice.mActive = true;
	UnlockMixer();
	return true;
}

// ===========================================================================
// Decodificacion de efectos (no toca el lock: corre en el hilo que carga)
// ===========================================================================
namespace
{

unsigned char* ReadWholeFile(const std::string& thePath, int& theSizeOut)
{
	PFILE* fp = p_fopen(thePath.c_str(), "rb");
	if (fp == NULL)
		return NULL;

	p_fseek(fp, 0, SEEK_END);
	const int aSize = (int)p_ftell(fp);
	p_fseek(fp, 0, SEEK_SET);
	if (aSize <= 0)
	{
		p_fclose(fp);
		return NULL;
	}
	unsigned char* aData = (unsigned char*)malloc((size_t)aSize);
	if (aData == NULL)
	{
		p_fclose(fp);
		return NULL;
	}
	const bool aOk = ((int)p_fread(aData, 1, aSize, fp) == aSize);
	p_fclose(fp);
	if (!aOk)
	{
		free(aData);
		return NULL;
	}
	theSizeOut = aSize;
	return aData;
}

inline unsigned int RdLE16(const unsigned char* p) { return (unsigned int)p[0] | ((unsigned int)p[1] << 8); }
inline unsigned int RdLE32(const unsigned char* p)
{
	return (unsigned int)p[0] | ((unsigned int)p[1] << 8) | ((unsigned int)p[2] << 16) | ((unsigned int)p[3] << 24);
}

Ps3Sample* DecodeOgg(const unsigned char* theData, int theSize)
{
	int aChannels = 0, aRate = 0;
	short* aDecoded = NULL;
	const int aFrames = stb_vorbis_decode_memory(theData, theSize, &aChannels, &aRate, &aDecoded);
	if (aFrames <= 0 || aDecoded == NULL || aChannels < 1 || aChannels > 2 || aRate <= 0)
	{
		free(aDecoded);
		return NULL;
	}
	Ps3Sample* aSample = new Ps3Sample();
	aSample->mPCM = aDecoded;		// ya es malloc'd, 16 bit, endian nativo
	aSample->mFrames = aFrames;
	aSample->mRate = aRate;
	aSample->mChannels = aChannels;
	return aSample;
}

// RIFF/WAVE PCM 16 bit. WAV es little-endian: hay que girar cabeceras Y muestras
// (si solo se giran las cabeceras suena "ruido blanco").
Ps3Sample* DecodeWav(const unsigned char* theData, int theSize)
{
	if (theSize < 44 || memcmp(theData, "RIFF", 4) != 0 || memcmp(theData + 8, "WAVE", 4) != 0)
		return NULL;

	int aChannels = 0, aRate = 0, aBits = 0;
	const unsigned char* aSamples = NULL;
	int aSampleBytes = 0;

	int aPos = 12;
	while (aPos + 8 <= theSize)
	{
		unsigned int aChunkSize = RdLE32(theData + aPos + 4);
		const unsigned char* aBody = theData + aPos + 8;
		const int aBodyMax = theSize - (aPos + 8);
		if ((int)aChunkSize > aBodyMax)
			aChunkSize = (unsigned int)(aBodyMax > 0 ? aBodyMax : 0);

		if (memcmp(theData + aPos, "fmt ", 4) == 0 && aChunkSize >= 16)
		{
			if (RdLE16(aBody) != 1)		// solo PCM
				return NULL;
			aChannels = (int)RdLE16(aBody + 2);
			aRate = (int)RdLE32(aBody + 4);
			aBits = (int)RdLE16(aBody + 14);
		}
		else if (memcmp(theData + aPos, "data", 4) == 0)
		{
			aSamples = aBody;
			aSampleBytes = (int)aChunkSize;
		}
		aPos += 8 + (int)aChunkSize + ((aChunkSize & 1) ? 1 : 0);
	}

	if (aSamples == NULL || aSampleBytes <= 0 || aBits != 16 ||
		aChannels < 1 || aChannels > 2 || aRate <= 0)
		return NULL;

	const int aCount = aSampleBytes / 2;
	const int aFrames = aCount / aChannels;
	if (aFrames <= 0)
		return NULL;

	short* aPCM = (short*)malloc((size_t)aFrames * aChannels * sizeof(short));
	if (aPCM == NULL)
		return NULL;
	for (int i = 0; i < aFrames * aChannels; i++)
		aPCM[i] = (short)RdLE16(aSamples + i * 2);

	Ps3Sample* aSample = new Ps3Sample();
	aSample->mPCM = aPCM;
	aSample->mFrames = aFrames;
	aSample->mRate = aRate;
	aSample->mChannels = aChannels;
	return aSample;
}

Ps3Sample* LoadSampleFromPak(const std::string& theBaseName)
{
	static const char* const kFormats[] = { ".ogg", ".wav" };
	for (int f = 0; f < 2; f++)
	{
		const std::string aFilename = theBaseName + kFormats[f];
		int aSize = 0;
		unsigned char* aData = ReadWholeFile(aFilename, aSize);
		if (aData == NULL)
			continue;
		Ps3Sample* aSample = (f == 0) ? DecodeOgg(aData, aSize) : DecodeWav(aData, aSize);
		free(aData);
		if (aSample != NULL)
			return aSample;
		printf("[PS3][SND] failed to decode %s\n", aFilename.c_str());
	}
	return NULL;
}

} // namespace

// ===========================================================================
// Ps3SoundInstance
// ===========================================================================

Ps3SoundInstance::Ps3SoundInstance(Ps3SoundManager* theManager, int theSfxID)
	: mManager(theManager), mSfxID(theSfxID), mVoice(-1), mSerial(0),
	  mBaseVolume(theManager->mBaseVolumes[theSfxID]), mVolume(1.0),
	  mBasePan(theManager->mBasePans[theSfxID]), mPan(0),
	  mPitchRatio(1.0), mReleased(false), mAutoRelease(false)
{
}

bool Ps3SoundInstance::VoiceAliveLocked()
{
	if (mVoice < 0)
		return false;
	const Ps3Voice& aVoice = g_voices[mVoice];
	if (!aVoice.mActive || aVoice.mSerial != mSerial)
	{
		mVoice = -1;		// termino o se la robo otro efecto
		return false;
	}
	return true;
}

void Ps3SoundInstance::ApplyVolumeLocked()
{
	if (!VoiceAliveLocked())
		return;
	const double aVol = mBaseVolume * mVolume * mManager->mMasterVolume;
	ApplyPan(aVol, mBasePan + mPan, g_voices[mVoice].mVolL, g_voices[mVoice].mVolR);
}

void Ps3SoundInstance::ApplyVolume()
{
	LockMixer();
	ApplyVolumeLocked();
	UnlockMixer();
}

void Ps3SoundInstance::Release()
{
	Stop();
	mReleased = true;
}

void Ps3SoundInstance::SetBaseVolume(double theBaseVolume)
{
	mBaseVolume = theBaseVolume;
	ApplyVolume();
}

void Ps3SoundInstance::SetBasePan(int theBasePan)
{
	mBasePan = theBasePan;
	ApplyVolume();
}

void Ps3SoundInstance::AdjustPitch(double theNumSteps)
{
	mPitchRatio = pow(2.0, theNumSteps / 12.0);
	LockMixer();
	if (VoiceAliveLocked())
	{
		Ps3Voice& aVoice = g_voices[mVoice];
		aVoice.mStep = (double)aVoice.mSample->mRate * mPitchRatio / (double)PS3_OUT_RATE;
	}
	UnlockMixer();
}

void Ps3SoundInstance::SetVolume(double theVolume)
{
	mVolume = theVolume;
	ApplyVolume();
}

void Ps3SoundInstance::SetPan(int thePosition)
{
	mPan = thePosition;
	ApplyVolume();
}

bool Ps3SoundInstance::Play(bool looping, bool autoRelease)
{
	Stop();
	mAutoRelease = autoRelease;

	// Se vuelve a decodificar aca (y no solo en GetSoundInstance) para que una
	// instancia de larga vida siga sonando despues de un PurgeSounds().
	if (!mManager->EnsureSampleLoaded((unsigned int)mSfxID))
		return false;

	LockMixer();
	Ps3Sample* aSample = mManager->mSamples[mSfxID];
	if (aSample == NULL || !g_audioUp)
	{
		UnlockMixer();
		return false;
	}

	// Voz libre, o robar la mas vieja.
	int aVoiceIdx = -1;
	for (int v = 0; v < PS3_MAX_VOICES; v++)
	{
		if (!g_voices[v].mActive)
		{
			aVoiceIdx = v;
			break;
		}
	}
	if (aVoiceIdx < 0)
	{
		unsigned int aOldest = 0xFFFFFFFFu;
		for (int v = 0; v < PS3_MAX_VOICES; v++)
		{
			if (g_voices[v].mStamp < aOldest)
			{
				aOldest = g_voices[v].mStamp;
				aVoiceIdx = v;
			}
		}
		ReleaseVoiceLocked(aVoiceIdx);
	}

	Ps3Voice& aVoice = g_voices[aVoiceIdx];
	aSample->mRef++;
	aVoice.mSample = aSample;
	aVoice.mPos = 0.0;
	aVoice.mStep = (double)aSample->mRate * mPitchRatio / (double)PS3_OUT_RATE;
	aVoice.mLoop = looping;
	aVoice.mSerial = ++g_serialCounter;
	aVoice.mStamp = ++g_stampCounter;
	mSerial = aVoice.mSerial;
	mVoice = aVoiceIdx;

	const double aVol = mBaseVolume * mVolume * mManager->mMasterVolume;
	ApplyPan(aVol, mBasePan + mPan, aVoice.mVolL, aVoice.mVolR);
	aVoice.mActive = true;		// ultimo: el mezclador recien ahora la ve
	UnlockMixer();
	return true;
}

void Ps3SoundInstance::Stop()
{
	LockMixer();
	if (VoiceAliveLocked())
	{
		ReleaseVoiceLocked(mVoice);
		mVoice = -1;
	}
	UnlockMixer();
}

bool Ps3SoundInstance::IsPlaying()
{
	LockMixer();
	const bool aPlaying = VoiceAliveLocked();
	UnlockMixer();
	return aPlaying;
}

bool Ps3SoundInstance::IsReleased()
{
	return mReleased;
}

double Ps3SoundInstance::GetVolume()
{
	return mVolume;
}

// ===========================================================================
// Ps3SoundManager
// ===========================================================================

Ps3SoundManager::Ps3SoundManager()
	: mInitialized(false), mMasterVolume(1.0)
{
	for (int i = 0; i < MAX_SOURCE_SOUNDS; i++)
	{
		mSamples[i] = NULL;
		mBaseVolumes[i] = 1.0;
		mBasePans[i] = 0;
	}
	// Si libaudio falla el juego sigue, mudo: Initialized() devuelve true igual
	// (como DummySoundManager) para que nada se queje por falta de audio.
	mInitialized = Ps3AudioInit();
}

Ps3SoundManager::~Ps3SoundManager()
{
	StopAllSounds();
	ReleaseSounds();
	LockMixer();
	for (std::list<Ps3SoundInstance*>::iterator anItr = mInstances.begin(); anItr != mInstances.end(); ++anItr)
		delete *anItr;
	mInstances.clear();
	UnlockMixer();
	Ps3AudioShutdown();
}

bool Ps3SoundManager::Initialized()
{
	return true;
}

void Ps3SoundManager::FreeSampleLocked(unsigned int theSfxID)
{
	ReleaseSampleLocked(mSamples[theSfxID]);		// las voces activas conservan su ref
	mSamples[theSfxID] = NULL;
}

bool Ps3SoundManager::EnsureSampleLoaded(unsigned int theSfxID)
{
	if (theSfxID >= MAX_SOURCE_SOUNDS || !mInitialized)
		return false;

	LockMixer();
	if (mSamples[theSfxID] != NULL)
	{
		UnlockMixer();
		return true;
	}
	if (mSourceFileNames[theSfxID].empty())
	{
		UnlockMixer();
		return false;
	}
	const std::string aBaseName = mSourceFileNames[theSfxID];
	UnlockMixer();

	// Decodificar sin el lock: el mezclador no puede esperar por un OGG entero.
	Ps3Sample* aSample = LoadSampleFromPak(aBaseName);

	LockMixer();
	if (aSample == NULL)
	{
		// Falta o no decodifica: limpiar el nombre para no reintentar en cada play.
		if (mSamples[theSfxID] == NULL && mSourceFileNames[theSfxID] == aBaseName)
			mSourceFileNames[theSfxID].clear();
		UnlockMixer();
		return false;
	}
	if (mSamples[theSfxID] != NULL || mSourceFileNames[theSfxID] != aBaseName)
	{
		// Otro hilo la cargo (o el id cambio) mientras decodificabamos.
		const bool aHave = (mSamples[theSfxID] != NULL);
		ReleaseSampleLocked(aSample);
		UnlockMixer();
		return aHave;
	}
	mSamples[theSfxID] = aSample;
	UnlockMixer();
	return true;
}

bool Ps3SoundManager::LoadSound(unsigned int theSfxID, const std::string& theFilename)
{
	if (theSfxID >= MAX_SOURCE_SOUNDS)
		return false;
	LockMixer();
	FreeSampleLocked(theSfxID);
	mSourceFileNames[theSfxID] = theFilename;
	UnlockMixer();
	// La decodificacion es perezosa: la mayoria de los ids no se tocan en una sesion.
	return true;
}

int Ps3SoundManager::LoadSound(const std::string& theFilename)
{
	LockMixer();
	int aFound = -1;
	for (int i = 0; i < MAX_SOURCE_SOUNDS; i++)
	{
		if (!mSourceFileNames[i].empty() && mSourceFileNames[i] == theFilename)
		{
			aFound = i;
			break;
		}
	}
	if (aFound < 0)
	{
		for (int i = 0; i < MAX_SOURCE_SOUNDS; i++)
		{
			if (mSourceFileNames[i].empty() && mSamples[i] == NULL)
			{
				mSourceFileNames[i] = theFilename;
				aFound = i;
				break;
			}
		}
	}
	UnlockMixer();
	return aFound;
}

void Ps3SoundManager::ReleaseSound(unsigned int theSfxID)
{
	if (theSfxID >= MAX_SOURCE_SOUNDS)
		return;
	LockMixer();
	FreeSampleLocked(theSfxID);
	mSourceFileNames[theSfxID].clear();
	UnlockMixer();
}

void Ps3SoundManager::SetVolume(double theVolume)
{
	SetMasterVolume(theVolume);
}

bool Ps3SoundManager::SetBaseVolume(unsigned int theSfxID, double theBaseVolume)
{
	if (theSfxID >= MAX_SOURCE_SOUNDS)
		return false;
	mBaseVolumes[theSfxID] = theBaseVolume;
	return true;
}

bool Ps3SoundManager::SetBasePan(unsigned int theSfxID, int theBasePan)
{
	if (theSfxID >= MAX_SOURCE_SOUNDS)
		return false;
	mBasePans[theSfxID] = theBasePan;
	return true;
}

// Las instancias son del manager, no del que llama: el juego hace Release() y
// se va. Se borran en la proxima llamada al manager.
void Ps3SoundManager::ReapDeadInstancesLocked()
{
	std::list<Ps3SoundInstance*>::iterator anItr = mInstances.begin();
	while (anItr != mInstances.end())
	{
		Ps3SoundInstance* anInstance = *anItr;
		bool aDone = anInstance->mReleased;
		if (!aDone && anInstance->mAutoRelease)
			aDone = !anInstance->VoiceAliveLocked();

		if (aDone)
		{
			anItr = mInstances.erase(anItr);
			delete anInstance;
		}
		else
			++anItr;
	}
}

SoundInstance* Ps3SoundManager::GetSoundInstance(unsigned int theSfxID)
{
	if (theSfxID >= MAX_SOURCE_SOUNDS)
		return NULL;

	LockMixer();
	ReapDeadInstancesLocked();
	Ps3SoundInstance* anInstance = new Ps3SoundInstance(this, (int)theSfxID);
	mInstances.push_back(anInstance);
	UnlockMixer();
	return anInstance;
}

void Ps3SoundManager::ReleaseSounds()
{
	LockMixer();
	for (int i = 0; i < MAX_SOURCE_SOUNDS; i++)
	{
		FreeSampleLocked((unsigned int)i);
		mSourceFileNames[i].clear();
	}
	UnlockMixer();
}

void Ps3SoundManager::ReleaseChannels()
{
	StopAllSounds();
}

double Ps3SoundManager::GetMasterVolume()
{
	return mMasterVolume;
}

void Ps3SoundManager::SetMasterVolume(double theVolume)
{
	if (theVolume < 0.0) theVolume = 0.0;
	if (theVolume > 1.0) theVolume = 1.0;
	LockMixer();
	mMasterVolume = theVolume;
	for (std::list<Ps3SoundInstance*>::iterator anItr = mInstances.begin(); anItr != mInstances.end(); ++anItr)
		(*anItr)->ApplyVolumeLocked();
	UnlockMixer();
}

void Ps3SoundManager::Flush()
{
}

void Ps3SoundManager::SetCooperativeWindow(HWND)
{
}

void Ps3SoundManager::StopAllSounds()
{
	LockMixer();
	for (int v = 0; v < PS3_MAX_VOICES; v++)
		ReleaseVoiceLocked(v);
	UnlockMixer();
}

int Ps3SoundManager::GetFreeSoundId()
{
	LockMixer();
	int aResult = -1;
	for (int i = 0; i < MAX_SOURCE_SOUNDS; i++)
	{
		if (mSourceFileNames[i].empty() && mSamples[i] == NULL)
		{
			aResult = i;
			break;
		}
	}
	UnlockMixer();
	return aResult;
}

int Ps3SoundManager::GetNumSounds()
{
	LockMixer();
	int aCount = 0;
	for (int i = 0; i < MAX_SOURCE_SOUNDS; i++)
		if (!mSourceFileNames[i].empty())
			++aCount;
	UnlockMixer();
	return aCount;
}

// LOW_MEMORY: suelta el PCM decodificado pero conserva los nombres, asi cada
// sonido se vuelve a decodificar al primer Play. Las voces vivas no se cortan.
void Ps3SoundManager::PurgeSounds()
{
	LockMixer();
	for (int i = 0; i < MAX_SOURCE_SOUNDS; i++)
		FreeSampleLocked((unsigned int)i);
	UnlockMixer();
}

void Ps3SoundManager::PreloadSound(unsigned int theSfxID)
{
	EnsureSampleLoaded(theSfxID);
}

// ===========================================================================
// Musica: API de streaming (la que llama Lawn/System/Music.cpp)
// ===========================================================================

bool Sexy::Ps3MusicPlay(unsigned char* theOggData, int theSize, bool theLoop)
{
	if (theOggData == NULL)
		return false;
	if (!g_audioUp)
	{
		free(theOggData);
		return false;
	}

	// Abrir el decoder aca (en el hilo del juego) para poder devolver el error;
	// solo el hilo mezclador lo usa despues.
	int anError = 0;
	stb_vorbis* aVorbis = stb_vorbis_open_memory(theOggData, theSize, &anError, NULL);
	if (aVorbis == NULL)
	{
		printf("[PS3][MUS] stb_vorbis_open_memory failed (err %d, %d KB)\n", anError, theSize / 1024);
		free(theOggData);
		return false;
	}
	const stb_vorbis_info anInfo = stb_vorbis_get_info(aVorbis);
	if (anInfo.channels < 1 || anInfo.channels > 2 || anInfo.sample_rate == 0)
	{
		printf("[PS3][MUS] unsupported OGG (%d ch, %u Hz)\n", anInfo.channels, anInfo.sample_rate);
		stb_vorbis_close(aVorbis);
		free(theOggData);
		return false;
	}

	LockMixer();
	// Si habia una cancion nueva sin adoptar todavia, se descarta.
	stb_vorbis* aDropV = g_musPending.mVorbis;
	unsigned char* aDropD = g_musPending.mData;
	g_musPending.mVorbis = aVorbis;
	g_musPending.mData = theOggData;
	g_musPending.mRate = (int)anInfo.sample_rate;
	g_musPending.mLoop = theLoop;
	g_musPending.mHasNew = true;
	g_musPending.mStop = true;		// reemplaza a la que suena
	g_musPlaying = 1;
	g_musPaused = 0;
	UnlockMixer();
	FreeMusicResources(aDropV, aDropD);
	return true;
}

void Sexy::Ps3MusicStop()
{
	LockMixer();
	stb_vorbis* aDropV = g_musPending.mVorbis;
	unsigned char* aDropD = g_musPending.mData;
	g_musPending.mVorbis = NULL;
	g_musPending.mData = NULL;
	g_musPending.mHasNew = false;
	g_musPending.mStop = true;		// el mezclador cierra la activa
	g_musPlaying = 0;
	UnlockMixer();
	FreeMusicResources(aDropV, aDropD);
}

void Sexy::Ps3MusicSetPaused(bool thePaused)
{
	g_musPaused = thePaused ? 1 : 0;
}

bool Sexy::Ps3MusicIsPlaying()
{
	return g_musPlaying != 0;
}

void Sexy::Ps3MusicSetVolume(double theVolume)
{
	if (theVolume < 0.0) theVolume = 0.0;
	if (theVolume > 1.0) theVolume = 1.0;
	g_musVolume = (float)theVolume;
}

void Sexy::Ps3MusicSetMasterVolume(double theVolume)
{
	if (theVolume < 0.0) theVolume = 0.0;
	if (theVolume > 1.0) theVolume = 1.0;
	g_musMaster = (float)theVolume;
}

// ===========================================================================
// Ps3MusicInterface (mismo contrato que WiiMusicInterface)
// ===========================================================================
namespace
{
int s_musCurrentSongId = -1;
}

Ps3MusicInterface::Ps3MusicInterface() {}

Ps3MusicInterface::~Ps3MusicInterface()
{
	Ps3MusicStop();
}

bool Ps3MusicInterface::LoadMusic(int, const std::string&) { return true; }

void Ps3MusicInterface::PlayMusic(int theSongId, int, bool)
{
	s_musCurrentSongId = theSongId;
}

void Ps3MusicInterface::StopMusic(int theSongId)
{
	if (s_musCurrentSongId == theSongId || theSongId < 0)
	{
		Ps3MusicStop();
		s_musCurrentSongId = -1;
	}
}

void Ps3MusicInterface::PauseMusic(int theSongId)
{
	if (s_musCurrentSongId == theSongId)
		Ps3MusicSetPaused(true);
}

void Ps3MusicInterface::ResumeMusic(int theSongId)
{
	if (s_musCurrentSongId == theSongId)
		Ps3MusicSetPaused(false);
}

void Ps3MusicInterface::StopAllMusic()
{
	Ps3MusicStop();
	s_musCurrentSongId = -1;
}

void Ps3MusicInterface::UnloadMusic(int theSongId) { StopMusic(theSongId); }
void Ps3MusicInterface::UnloadAllMusic() { StopAllMusic(); }
void Ps3MusicInterface::PauseAllMusic() { Ps3MusicSetPaused(true); }
void Ps3MusicInterface::ResumeAllMusic() { Ps3MusicSetPaused(false); }

void Ps3MusicInterface::FadeIn(int theSongId, int, double, bool)
{
	s_musCurrentSongId = theSongId;
	Ps3MusicSetVolume(1.0);
	Ps3MusicSetPaused(false);
}

void Ps3MusicInterface::FadeOut(int theSongId, bool stopSong, double)
{
	if (s_musCurrentSongId != theSongId)
		return;
	if (stopSong)
		StopMusic(theSongId);
	else
		Ps3MusicSetVolume(0.0);
}

void Ps3MusicInterface::FadeOutAll(bool stopSong, double)
{
	if (stopSong)
		StopAllMusic();
	else
		Ps3MusicSetVolume(0.0);
}

void Ps3MusicInterface::SetSongVolume(int theSongId, double theVolume)
{
	if (s_musCurrentSongId == theSongId)
		Ps3MusicSetVolume(theVolume);
}

void Ps3MusicInterface::SetSongMaxVolume(int theSongId, double theMaxVolume)
{
	if (s_musCurrentSongId == theSongId)
		Ps3MusicSetVolume(theMaxVolume);
}

bool Ps3MusicInterface::IsPlaying(int theSongId)
{
	return s_musCurrentSongId == theSongId && Ps3MusicIsPlaying();
}

void Ps3MusicInterface::SetVolume(double theVolume)
{
	Ps3MusicSetMasterVolume(theVolume);
}

void Ps3MusicInterface::SetMusicAmplify(int, double) {}
void Ps3MusicInterface::Update() {}

#endif // PS3_PLATFORM
