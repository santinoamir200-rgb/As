#pragma once
// Mini "OpenGL 1.x" para PS3. El juego (platform/pc/graphics/GLInterface.cpp)
// usa solo ~25 funciones de GL de funcion fija; esto es exactamente ese
// subconjunto. La implementacion real sobre RSX va en ps3gl.cpp (Parte 2/3).
#ifdef __cplusplus
extern "C" {
#endif

typedef unsigned int GLenum;
typedef unsigned int GLuint;
typedef int GLint;
typedef int GLsizei;
typedef unsigned int GLbitfield;
typedef unsigned char GLboolean;
typedef float GLfloat;
typedef float GLclampf;
typedef double GLdouble;
typedef void GLvoid;

#define GL_NO_ERROR 0
#define GL_OUT_OF_MEMORY 0x0505
#define GL_TRUE 1
#define GL_ONE 1
#define GL_SRC_ALPHA 0x0302
#define GL_ONE_MINUS_SRC_ALPHA 0x0303
#define GL_BLEND 0x0BE2
#define GL_CULL_FACE 0x0B44
#define GL_DEPTH_TEST 0x0B71
#define GL_DITHER 0x0BD0
#define GL_LIGHTING 0x0B50
#define GL_TEXTURE_2D 0x0DE1
#define GL_MAX_TEXTURE_SIZE 0x0D33
#define GL_COLOR_BUFFER_BIT 0x4000
#define GL_LINE_STRIP 0x0003
#define GL_TRIANGLES 0x0004
#define GL_TRIANGLE_STRIP 0x0005
#define GL_TRIANGLE_FAN 0x0006
#define GL_MODELVIEW 0x1700
#define GL_PROJECTION 0x1701
#define GL_UNSIGNED_BYTE 0x1401
#define GL_FLOAT 0x1406
#define GL_RGB 0x1907
#define GL_RGBA 0x1908
#define GL_RGBA4 0x8056
#define GL_BGRA 0x80E1
#define GL_UNSIGNED_SHORT_5_6_5 0x8363
#define GL_UNSIGNED_SHORT_4_4_4_4_REV 0x8365
#define GL_UNSIGNED_INT_8_8_8_8_REV 0x8367
#define GL_NEAREST 0x2600
#define GL_LINEAR 0x2601
#define GL_TEXTURE_MAG_FILTER 0x2800
#define GL_TEXTURE_MIN_FILTER 0x2801
#define GL_TEXTURE_WRAP_S 0x2802
#define GL_TEXTURE_WRAP_T 0x2803
#define GL_CLAMP_TO_EDGE 0x812F
#define GL_VERTEX_ARRAY 0x8074
#define GL_COLOR_ARRAY 0x8076
#define GL_TEXTURE_COORD_ARRAY 0x8078

void glEnable(GLenum cap);
void glDisable(GLenum cap);
void glEnableClientState(GLenum array);
void glDisableClientState(GLenum array);
void glBlendFunc(GLenum sfactor, GLenum dfactor);
void glClear(GLbitfield mask);
void glClearColor(GLclampf r, GLclampf g, GLclampf b, GLclampf a);
void glViewport(GLint x, GLint y, GLsizei w, GLsizei h);
void glMatrixMode(GLenum mode);
void glLoadIdentity(void);
void glOrtho(GLdouble l, GLdouble r, GLdouble b, GLdouble t, GLdouble n, GLdouble f);
void glGenTextures(GLsizei n, GLuint* textures);
void glDeleteTextures(GLsizei n, const GLuint* textures);
void glBindTexture(GLenum target, GLuint texture);
void glTexParameteri(GLenum target, GLenum pname, GLint param);
void glTexImage2D(GLenum target, GLint level, GLint internalformat, GLsizei w, GLsizei h, GLint border, GLenum format, GLenum type, const GLvoid* pixels);
void glTexSubImage2D(GLenum target, GLint level, GLint xoff, GLint yoff, GLsizei w, GLsizei h, GLenum format, GLenum type, const GLvoid* pixels);
void glGetTexImage(GLenum target, GLint level, GLenum format, GLenum type, GLvoid* pixels);
void glVertexPointer(GLint size, GLenum type, GLsizei stride, const GLvoid* ptr);
void glColorPointer(GLint size, GLenum type, GLsizei stride, const GLvoid* ptr);
void glTexCoordPointer(GLint size, GLenum type, GLsizei stride, const GLvoid* ptr);
void glDrawArrays(GLenum mode, GLint first, GLsizei count);
GLenum glGetError(void);
void glGetIntegerv(GLenum pname, GLint* params);

#ifdef __cplusplus
}
#endif
