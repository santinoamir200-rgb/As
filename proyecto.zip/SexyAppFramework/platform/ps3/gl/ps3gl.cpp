// ps3gl.cpp - backend "OpenGL 1.x minimo" sobre RSX (PSL1GHT) para PS3.
//
// PARTE 2: rsxInit, framebuffers 720p doble buffer, flip con vsync.
// PARTE 3 (esta): vertex/fragment program, matrices, texturas, blend y
//                 glDrawArrays (quads/triangulos texturizados).
//
// Equivale al papel de gx_wii.cpp + opengx: el juego (GLInterface.cpp) habla
// el subconjunto de GL de GL/gl.h y esto lo traduce a comandos RSX.
//
// Decisiones de diseno
//  * RSX no tiene pipeline fijo: un unico vertex program (mvp * pos, pasa color
//    y uv) y dos fragment programs (con textura = GL_MODULATE, y sin textura).
//    Se compilan desde shaders/*.vcg|*.fcg (ver CMake/ps3_shaders.cmake).
//  * Las matrices viven en CPU (fila-mayor); se sube mvp = proj * modelview.
//  * Texturas: siempre A8R8G8B8 lineales en memoria local de RSX. Los formatos
//    del juego (BGRA 8888_REV, BGRA 4444_REV, RGB 565) se convierten en CPU al
//    subirlos. Los tipos empaquetados se leen como palabras NATIVAS (big-endian),
//    que es la semantica de GL.
//  * Vertices: se copian cada draw a un ring buffer en memoria RSX (3 regiones,
//    una por frame en vuelo). GL_TRIANGLE_FAN se expande a triangulos en CPU.
//  * Seguridad CPU/GPU: no se escribe una textura que RSX pueda estar leyendo
//    (se espera a la GPU) y los buffers liberados se destruyen 3 frames despues.
#ifdef PS3_PLATFORM
#include "ps3gl.h"

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <malloc.h>
#include <unistd.h>
#include <vector>

#include <ppu-types.h>
#include <sysutil/sysutil.h>
#include <sysutil/video.h>
#include <rsx/gcm_sys.h>
#include <rsx/rsx.h>

// ---------------------------------------------------------------------------
// Configuracion (se puede pisar con -D en CMake)
// ---------------------------------------------------------------------------
#ifndef PS3GL_CMD_SIZE
#define PS3GL_CMD_SIZE   (1024 * 1024)       // command buffer de RSX
#endif
#ifndef PS3GL_HOST_SIZE
#define PS3GL_HOST_SIZE  (8 * 1024 * 1024)   // memoria host mapeada a RSX (multiplo de 1 MB)
#endif
#ifndef PS3GL_TEST_QUAD
#define PS3GL_TEST_QUAD  0                   // 1 = cada swap dibuja ademas el quad de prueba
#endif
#ifndef PS3GL_HANDLE_SYSUTIL
#define PS3GL_HANDLE_SYSUTIL 1               // registra el callback del XMB (slot 0)
#endif
#ifndef PS3GL_RING_REGION_BYTES
#define PS3GL_RING_REGION_BYTES (4 * 1024 * 1024)  // vertices por frame (x3 regiones)
#endif
#ifndef PS3GL_MAX_TEXTURE_SIZE
#define PS3GL_MAX_TEXTURE_SIZE 4096          // limite de texturas lineales en RSX
#endif

// Shaders embebidos por CMake (CMake/ps3_shaders.cmake).
#ifndef PS3GL_NO_SHADERS
extern "C" {
extern const unsigned char ps3gl_vp_vpo[];
extern const unsigned char ps3gl_fp_flat_fpo[];
extern const unsigned char ps3gl_fp_tex_fpo[];
}
#endif

namespace
{

constexpr int      kBufferCount = 2;
constexpr uint32_t kBgColor     = 0xFF202020u;  // gris oscuro (A8R8G8B8)
constexpr int      kRegions     = 3;            // regiones del ring de vertices
constexpr uint32_t kRegionBytes = PS3GL_RING_REGION_BYTES;
constexpr int      kDeferFrames = 3;            // frames antes de liberar memoria RSX

constexpr GLenum kGlInvalidEnum  = 0x0500;
constexpr GLenum kGlInvalidValue = 0x0501;

// ---------------------------------------------------------------------------
// Tipos
// ---------------------------------------------------------------------------
struct ColorBuffer
{
	uint32_t* ptr    = nullptr;
	uint32_t  offset = 0;
};

// Vertice que lee el vertex program: 24 bytes, igual al GLVertex del juego.
struct OutVertex
{
	float   x, y, z;
	uint8_t r, g, b, a;
	float   u, v;
};
static_assert(sizeof(OutVertex) == 24, "OutVertex debe medir 24 bytes");

struct Tex
{
	uint32_t* data       = nullptr;   // memoria local de RSX
	uint32_t  offset     = 0;
	int       w = 0, h = 0;
	uint32_t  pitch      = 0;         // bytes por fila
	GLenum    minFilter  = GL_NEAREST;
	GLenum    magFilter  = GL_NEAREST;
	bool      dirty      = true;      // hay que recargar estado/cache en RSX
	int64_t   lastUsed   = -100;      // ultimo frame en que un draw la uso
};

struct Mat4 { float m[16]; };          // fila-mayor: m[fila*4 + col]

struct FragProg
{
	rsxFragmentProgram* fpo = nullptr;
	void*     ucode   = nullptr;       // copia en memoria RSX
	uint32_t  offset  = 0;
	int       texUnit = 0;
};

struct ClientArray
{
	bool          enabled = false;
	GLint         size    = 0;
	GLenum        type    = GL_FLOAT;
	GLsizei       stride  = 0;
	const uint8_t* ptr    = nullptr;
};

struct Deferred { void* p; int64_t frame; };

// ---------------------------------------------------------------------------
// Estado global
// ---------------------------------------------------------------------------
gcmContextData* g_ctx        = nullptr;
void*           g_host       = nullptr;
ColorBuffer     g_color[kBufferCount];
uint32_t*       g_depth      = nullptr;
uint32_t        g_depthOff   = 0;
uint32_t        g_pitch      = 0;
uint32_t        g_depthPitch = 0;
int             g_width      = 1280;
int             g_height     = 720;
int             g_back       = 0;
bool            g_inited     = false;
bool            g_exitReq    = false;
bool            g_selftest   = false;
int64_t         g_frame      = 0;
uint32_t        g_finishRef  = 0;

// Estado GL
uint32_t g_clearColor = kBgColor;
int      g_vpX = 0, g_vpY = 0, g_vpW = 0, g_vpH = 0;     // viewport GL (origen abajo-izq)
bool     g_blend = false, g_depthTest = false, g_texEnabled = false;
GLenum   g_blendSrc = GL_ONE, g_blendDst = 0;            // 0 = ZERO
GLenum   g_matrixMode = GL_MODELVIEW;
Mat4     g_proj, g_mv;
ClientArray g_arr[3];                                    // 0 pos, 1 color, 2 uv
GLenum   sLastError = GL_NO_ERROR;

// Texturas
std::vector<Tex*>   g_tex(1, nullptr);                   // indice = nombre GL (0 reservado)
std::vector<GLuint> g_freeIds;
GLuint              g_boundTex = 0;
std::vector<Deferred> g_deferred;

// Programas
bool                g_progsOk   = false;
rsxVertexProgram*   g_vpo       = nullptr;
void*               g_vpUcode   = nullptr;
rsxProgramConst*    g_mvpConst  = nullptr;
int                 g_attrPos = 0, g_attrCol = 3, g_attrUv = 8;
FragProg            g_fp[2];                             // 0 flat, 1 texturado

// Cache de estado RSX (se invalida en cada begin_frame)
bool   g_vpLoaded  = false;
bool   g_mvpValid  = false;
float  g_lastMvp[16];
int    g_curFp     = -1;
Tex*   g_curTex    = nullptr;
bool   g_blendDirty = true;

// Ring de vertices
void*    g_ring       = nullptr;
uint32_t g_ringOffset = 0;                               // offset RSX de la base
uint32_t g_ringUsed   = 0;                               // bytes usados en la region actual

std::vector<OutVertex> g_scratch;

// Textura y vertices del quad de prueba
Tex* g_testTex = nullptr;

// Cursor por software (Parte 4)
float g_cursorX = 0.5f, g_cursorY = 0.5f;
bool  g_cursorVisible = false;

// ---------------------------------------------------------------------------
// Helpers generales
// ---------------------------------------------------------------------------
uint32_t PackARGB(float r, float g, float b, float a)
{
	auto q = [](float v) -> uint32_t {
		if (v < 0.0f) v = 0.0f;
		if (v > 1.0f) v = 1.0f;
		return (uint32_t)(v * 255.0f + 0.5f);
	};
	return (q(a) << 24) | (q(r) << 16) | (q(g) << 8) | q(b);
}

void SetError(GLenum e) { if (sLastError == GL_NO_ERROR) sLastError = e; }

#if PS3GL_HANDLE_SYSUTIL
void SysutilCallback(u64 status, u64 /*param*/, void* /*usrdata*/)
{
	if (status == SYSUTIL_EXIT_GAME)
		g_exitReq = true;
}
#endif

// Espera a que el ultimo gcmSetFlip se haya ejecutado (llega el vsync).
void WaitFlip()
{
	while (gcmGetFlipStatus() != 0)
		usleep(200);
	gcmResetFlipStatus();
}

bool QueueFlip(int bufferId)
{
	if (gcmSetFlip(g_ctx, (u8)bufferId) == 0)
	{
		rsxFlushBuffer(g_ctx);
		gcmSetWaitFlip(g_ctx);   // RSX espera el flip antes de seguir con comandos
		return true;
	}
	return false;
}

// Espera a que RSX termine TODO lo encolado. rsxFinish sigue una "referencia":
// si se repite el mismo valor no espera la segunda vez, por eso se incrementa.
void GpuIdle()
{
	if (!g_ctx) return;
	rsxFinish(g_ctx, ++g_finishRef);
}

// ---------------------------------------------------------------------------
// Memoria RSX con liberacion diferida
// ---------------------------------------------------------------------------
void ReleaseDeferred(bool all)
{
	size_t keep = 0;
	for (size_t i = 0; i < g_deferred.size(); ++i)
	{
		if (all || g_deferred[i].frame + kDeferFrames <= g_frame)
			rsxFree(g_deferred[i].p);
		else
			g_deferred[keep++] = g_deferred[i];
	}
	g_deferred.resize(keep);
}

void DeferFree(void* p)
{
	if (p) g_deferred.push_back({ p, g_frame });
}

// rsxMemalign con un reintento: si falla, espera a la GPU y libera lo diferido.
void* RsxAlloc(uint32_t align, uint32_t size)
{
	void* p = rsxMemalign(align, size);
	if (!p && (!g_deferred.empty()))
	{
		GpuIdle();
		ReleaseDeferred(true);
		p = rsxMemalign(align, size);
	}
	return p;
}

// ---------------------------------------------------------------------------
// Matematica (fila-mayor, vectores columna: v' = M * v)
// ---------------------------------------------------------------------------
Mat4 MatIdentity()
{
	Mat4 r;
	std::memset(&r, 0, sizeof(r));
	r.m[0] = r.m[5] = r.m[10] = r.m[15] = 1.0f;
	return r;
}

Mat4 MatMul(const Mat4& a, const Mat4& b)   // a * b
{
	Mat4 r;
	for (int i = 0; i < 4; ++i)
		for (int j = 0; j < 4; ++j)
		{
			float s = 0.0f;
			for (int k = 0; k < 4; ++k)
				s += a.m[i * 4 + k] * b.m[k * 4 + j];
			r.m[i * 4 + j] = s;
		}
	return r;
}

Mat4 MatOrtho(double l, double r, double b, double t, double n, double f)
{
	Mat4 o = MatIdentity();
	const double dx = r - l, dy = t - b, dz = f - n;
	if (dx == 0.0 || dy == 0.0 || dz == 0.0) return o;
	o.m[0]  = (float)(2.0 / dx);
	o.m[3]  = (float)(-(r + l) / dx);
	o.m[5]  = (float)(2.0 / dy);
	o.m[7]  = (float)(-(t + b) / dy);
	o.m[10] = (float)(-2.0 / dz);
	o.m[11] = (float)(-(f + n) / dz);
	return o;
}

// ---------------------------------------------------------------------------
// Render target / viewport / estado base
// ---------------------------------------------------------------------------
void SetRenderTarget(int id)
{
	gcmSurface sf;
	std::memset(&sf, 0, sizeof(sf));

	sf.type          = GCM_SURFACE_TYPE_LINEAR;
	sf.antiAlias     = GCM_SURFACE_CENTER_1;
	sf.colorFormat   = GCM_SURFACE_X8R8G8B8;
	sf.colorTarget   = GCM_SURFACE_TARGET_0;
	sf.colorLocation[0] = GCM_LOCATION_RSX;
	sf.colorOffset[0]   = g_color[id].offset;
	sf.colorPitch[0]    = g_pitch;
	for (int i = 1; i < GCM_MAX_MRT_COUNT; ++i)
	{
		sf.colorLocation[i] = GCM_LOCATION_RSX;
		sf.colorOffset[i]   = 0;
		sf.colorPitch[i]    = 64;   // valor minimo valido para MRT sin usar
	}
	sf.depthFormat   = GCM_SURFACE_ZETA_Z24S8;
	sf.depthLocation = GCM_LOCATION_RSX;
	sf.depthOffset   = g_depthOff;
	sf.depthPitch    = g_depthPitch;
	sf.width  = (u16)g_width;
	sf.height = (u16)g_height;
	sf.x = 0;
	sf.y = 0;

	rsxSetSurface(g_ctx, &sf);
}

// Viewport en coordenadas GL (origen abajo-izquierda) -> RSX (origen arriba-izq).
void ApplyViewport()
{
	const int w = (g_vpW > 0) ? g_vpW : g_width;
	const int h = (g_vpH > 0) ? g_vpH : g_height;
	const int x = g_vpX;
	const int y = g_height - (g_vpY + h);   // flip vertical

	f32 scale[4]  = { w * 0.5f, h * -0.5f, 0.5f, 0.0f };
	f32 offset[4] = { x + w * 0.5f, y + h * 0.5f, 0.5f, 0.0f };

	rsxSetViewport(g_ctx, (u16)x, (u16)y, (u16)w, (u16)h, 0.0f, 1.0f, scale, offset);
	for (int i = 0; i < 8; ++i)
		rsxSetViewportClip(g_ctx, (u8)i, (u16)g_width, (u16)g_height);
}

void SetFullScissor()
{
	rsxSetScissor(g_ctx, 0, 0, (u16)g_width, (u16)g_height);
}

void ClearColorAndDepth(uint32_t argb)
{
	SetFullScissor();
	rsxSetClearColor(g_ctx, argb);
	rsxSetClearDepthStencil(g_ctx, 0xFFFFFFFFu);
	rsxClearSurface(g_ctx,
		GCM_CLEAR_R | GCM_CLEAR_G | GCM_CLEAR_B | GCM_CLEAR_A |
		GCM_CLEAR_S | GCM_CLEAR_Z);
}

u32 GcmBlendFactor(GLenum f)
{
	switch (f)
	{
	case GL_SRC_ALPHA:           return GCM_SRC_ALPHA;
	case GL_ONE_MINUS_SRC_ALPHA: return GCM_ONE_MINUS_SRC_ALPHA;
	case GL_ONE:                 return GCM_ONE;
	default:                     return GCM_ZERO;
	}
}

void ApplyBlend()
{
	rsxSetBlendEnable(g_ctx, g_blend ? GCM_TRUE : GCM_FALSE);
	if (g_blend)
	{
		const u32 s = GcmBlendFactor(g_blendSrc);
		const u32 d = GcmBlendFactor(g_blendDst);
		// Orden de libgcm: (src color, src alpha, dst color, dst alpha).
		rsxSetBlendFunc(g_ctx, s, s, d, d);
		rsxSetBlendEquation(g_ctx, GCM_FUNC_ADD, GCM_FUNC_ADD);
	}
	g_blendDirty = false;
}

// Estado de RSX que sale del estado GL. Se reaplica cada frame.
void ApplyGlState()
{
	rsxSetColorMask(g_ctx,
		GCM_COLOR_MASK_B | GCM_COLOR_MASK_G | GCM_COLOR_MASK_R | GCM_COLOR_MASK_A);
	rsxSetColorMaskMrt(g_ctx, 0);
	rsxSetCullFaceEnable(g_ctx, GCM_FALSE);
	rsxSetDepthTestEnable(g_ctx, g_depthTest ? GCM_TRUE : GCM_FALSE);
	rsxSetDepthWriteEnable(g_ctx, g_depthTest ? GCM_TRUE : GCM_FALSE);
	rsxSetDepthFunc(g_ctx, GCM_LEQUAL);
	ApplyBlend();
}

// ---------------------------------------------------------------------------
// Programas (vertex + 2 fragment)
// ---------------------------------------------------------------------------
bool InitPrograms()
{
#ifdef PS3GL_NO_SHADERS
	return false;
#else
	g_vpo = reinterpret_cast<rsxVertexProgram*>(const_cast<unsigned char*>(ps3gl_vp_vpo));
	void* vuc = nullptr;
	u32   vsz = 0;
	rsxVertexProgramGetUCode(g_vpo, &vuc, &vsz);
	g_vpUcode  = vuc;
	g_mvpConst = rsxVertexProgramGetConst(g_vpo, "mvp");
	if (!g_vpUcode || !g_mvpConst)
	{
		std::printf("[PS3][GL] vertex program invalido (ucode=%p mvp=%p)\n", g_vpUcode, (void*)g_mvpConst);
		return false;
	}
	if (rsxProgramAttrib* a = rsxVertexProgramGetAttrib(g_vpo, "position")) g_attrPos = a->index;
	if (rsxProgramAttrib* a = rsxVertexProgramGetAttrib(g_vpo, "color"))    g_attrCol = a->index;
	if (rsxProgramAttrib* a = rsxVertexProgramGetAttrib(g_vpo, "texcoord")) g_attrUv  = a->index;

	const unsigned char* fpSrc[2] = { ps3gl_fp_flat_fpo, ps3gl_fp_tex_fpo };
	for (int i = 0; i < 2; ++i)
	{
		FragProg& fp = g_fp[i];
		fp.fpo = reinterpret_cast<rsxFragmentProgram*>(const_cast<unsigned char*>(fpSrc[i]));
		void* fuc = nullptr;
		u32   fsz = 0;
		rsxFragmentProgramGetUCode(fp.fpo, &fuc, &fsz);
		if (!fuc || fsz == 0) { std::printf("[PS3][GL] fragment program %d invalido\n", i); return false; }

		fp.ucode = rsxMemalign(128, fsz);   // el fragment program tiene que estar en memoria RSX
		if (!fp.ucode || rsxAddressToOffset(fp.ucode, &fp.offset) != 0)
		{
			std::printf("[PS3][GL] sin memoria RSX para el fragment program %d\n", i);
			return false;
		}
		std::memcpy(fp.ucode, fuc, fsz);

		fp.texUnit = 0;
		if (i == 1)
			if (rsxProgramAttrib* a = rsxFragmentProgramGetAttrib(fp.fpo, "tex")) fp.texUnit = a->index;
	}
	return true;
#endif
}

void FreePrograms()
{
	for (int i = 0; i < 2; ++i)
	{
		if (g_fp[i].ucode) rsxFree(g_fp[i].ucode);
		g_fp[i] = FragProg();
	}
	g_progsOk = false;
}

// ---------------------------------------------------------------------------
// Texturas
// ---------------------------------------------------------------------------
// Antes de escribir en una textura hay que estar seguros de que RSX no la esta
// leyendo: si un draw reciente la uso, se espera a la GPU.
void EnsureTexIdle(Tex* t)
{
	if (t->lastUsed >= g_frame - 1)
	{
		GpuIdle();
		t->lastUsed = -100;
	}
}

void TexRelease(Tex* t)
{
	if (t->data) { DeferFree(t->data); t->data = nullptr; }
	t->w = t->h = 0;
	t->pitch = 0;
	t->offset = 0;
}

bool TexAlloc(Tex* t, int w, int h)
{
	if (t->data && t->w == w && t->h == h)
		return true;
	TexRelease(t);
	if (w <= 0 || h <= 0 || w > PS3GL_MAX_TEXTURE_SIZE || h > PS3GL_MAX_TEXTURE_SIZE)
		return false;

	const uint32_t pitch = (((uint32_t)w * 4u) + 63u) & ~63u;   // pitch lineal multiplo de 64
	void* p = RsxAlloc(128, pitch * (uint32_t)h);
	if (!p || rsxAddressToOffset(p, &t->offset) != 0)
	{
		if (p) rsxFree(p);
		return false;
	}
	t->data  = static_cast<uint32_t*>(p);
	t->w     = w;
	t->h     = h;
	t->pitch = pitch;
	t->dirty = true;
	return true;
}

inline uint32_t Expand4(uint32_t v) { return v * 17u; }
inline uint32_t Expand5(uint32_t v) { return (v << 3) | (v >> 2); }
inline uint32_t Expand6(uint32_t v) { return (v << 2) | (v >> 4); }
inline uint32_t MakeARGB(uint32_t a, uint32_t r, uint32_t g, uint32_t b)
{
	return (a << 24) | (r << 16) | (g << 8) | b;
}

bool FormatSupported(GLenum fmt, GLenum type)
{
	if (type == GL_UNSIGNED_BYTE)
		return fmt == GL_RGBA || fmt == GL_BGRA || fmt == GL_RGB;
	if (type == GL_UNSIGNED_INT_8_8_8_8_REV || type == GL_UNSIGNED_SHORT_4_4_4_4_REV)
		return fmt == GL_RGBA || fmt == GL_BGRA;
	if (type == GL_UNSIGNED_SHORT_5_6_5)
		return fmt == GL_RGB;
	return false;
}

// Convierte 'n' pixeles de 'src' (formato/tipo GL) a A8R8G8B8 en 'dst'.
// Los tipos empaquetados se leen como palabras nativas (semantica de GL).
void ConvertRow(uint32_t* dst, const uint8_t* src, int n, GLenum fmt, GLenum type)
{
	if (type == GL_UNSIGNED_BYTE)
	{
		if (fmt == GL_RGBA)
			for (int i = 0; i < n; ++i, src += 4) dst[i] = MakeARGB(src[3], src[0], src[1], src[2]);
		else if (fmt == GL_BGRA)
			for (int i = 0; i < n; ++i, src += 4) dst[i] = MakeARGB(src[3], src[2], src[1], src[0]);
		else // GL_RGB
			for (int i = 0; i < n; ++i, src += 3) dst[i] = MakeARGB(255, src[0], src[1], src[2]);
	}
	else if (type == GL_UNSIGNED_INT_8_8_8_8_REV)
	{
		// REV: el primer componente del formato va en los bits bajos.
		const uint32_t* s = reinterpret_cast<const uint32_t*>(src);
		if (fmt == GL_BGRA)          // B=0-7 G=8-15 R=16-23 A=24-31  ==  0xAARRGGBB
			for (int i = 0; i < n; ++i) dst[i] = s[i];
		else                          // GL_RGBA: R=0-7 G=8-15 B=16-23 A=24-31
			for (int i = 0; i < n; ++i)
			{
				const uint32_t w = s[i];
				dst[i] = MakeARGB(w >> 24, w & 0xFF, (w >> 8) & 0xFF, (w >> 16) & 0xFF);
			}
	}
	else if (type == GL_UNSIGNED_SHORT_4_4_4_4_REV)
	{
		const uint16_t* s = reinterpret_cast<const uint16_t*>(src);
		for (int i = 0; i < n; ++i)
		{
			const uint32_t w = s[i];
			const uint32_t c0 = Expand4(w & 0xF), c1 = Expand4((w >> 4) & 0xF),
			               c2 = Expand4((w >> 8) & 0xF), a = Expand4((w >> 12) & 0xF);
			if (fmt == GL_BGRA) dst[i] = MakeARGB(a, c2, c1, c0);   // B,G,R
			else                dst[i] = MakeARGB(a, c0, c1, c2);   // R,G,B
		}
	}
	else // GL_UNSIGNED_SHORT_5_6_5, GL_RGB: R=15-11 G=10-5 B=4-0
	{
		const uint16_t* s = reinterpret_cast<const uint16_t*>(src);
		for (int i = 0; i < n; ++i)
		{
			const uint32_t w = s[i];
			dst[i] = MakeARGB(255, Expand5((w >> 11) & 0x1F), Expand6((w >> 5) & 0x3F), Expand5(w & 0x1F));
		}
	}
}

size_t PixelBytes(GLenum fmt, GLenum type)
{
	if (type == GL_UNSIGNED_BYTE)                 return fmt == GL_RGB ? 3 : 4;
	if (type == GL_UNSIGNED_INT_8_8_8_8_REV)      return 4;
	return 2;   // 4_4_4_4_REV, 5_6_5
}

// Sube un rectangulo (src con filas contiguas de 'w' pixeles) a la textura.
bool TexUpload(Tex* t, int xoff, int yoff, int w, int h, GLenum fmt, GLenum type, const void* pixels)
{
	if (!t->data || xoff < 0 || yoff < 0 || xoff + w > t->w || yoff + h > t->h)
		return false;
	EnsureTexIdle(t);

	const uint8_t* src = static_cast<const uint8_t*>(pixels);
	const size_t rowBytes = (size_t)w * PixelBytes(fmt, type);
	for (int y = 0; y < h; ++y)
	{
		uint32_t* dst = reinterpret_cast<uint32_t*>(
			reinterpret_cast<uint8_t*>(t->data) + (size_t)(yoff + y) * t->pitch) + xoff;
		ConvertRow(dst, src + (size_t)y * rowBytes, w, fmt, type);
	}
	__sync_synchronize();   // que las escrituras lleguen a memoria antes de que RSX las lea
	t->dirty = true;
	return true;
}

Tex* TexFromName(GLuint id)
{
	if (id == 0) return nullptr;
	if (id >= g_tex.size()) g_tex.resize(id + 1, nullptr);
	if (!g_tex[id]) g_tex[id] = new Tex();
	return g_tex[id];
}

GLuint TexNewName()
{
	GLuint id;
	if (!g_freeIds.empty()) { id = g_freeIds.back(); g_freeIds.pop_back(); }
	else                    { id = (GLuint)g_tex.size(); g_tex.push_back(nullptr); }
	g_tex[id] = new Tex();
	return id;
}

u32 GcmFilter(GLenum f) { return f == GL_LINEAR ? GCM_TEXTURE_LINEAR : GCM_TEXTURE_NEAREST; }

// Carga la textura en la unidad del fragment program texturizado.
void SetTexture(Tex* t)
{
	const u8 unit = (u8)g_fp[1].texUnit;

	gcmTexture tex;
	std::memset(&tex, 0, sizeof(tex));
	tex.format    = GCM_TEXTURE_FORMAT_A8R8G8B8 | GCM_TEXTURE_FORMAT_LIN;
	tex.mipmap    = 1;
	tex.dimension = GCM_TEXTURE_DIMS_2D;
	tex.cubemap   = GCM_FALSE;
	tex.remap     = ((GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_B_SHIFT) |
	                 (GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_G_SHIFT) |
	                 (GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_R_SHIFT) |
	                 (GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_A_SHIFT) |
	                 (GCM_TEXTURE_REMAP_COLOR_B << GCM_TEXTURE_REMAP_COLOR_B_SHIFT) |
	                 (GCM_TEXTURE_REMAP_COLOR_G << GCM_TEXTURE_REMAP_COLOR_G_SHIFT) |
	                 (GCM_TEXTURE_REMAP_COLOR_R << GCM_TEXTURE_REMAP_COLOR_R_SHIFT) |
	                 (GCM_TEXTURE_REMAP_COLOR_A << GCM_TEXTURE_REMAP_COLOR_A_SHIFT));
	tex.width     = (u16)t->w;
	tex.height    = (u16)t->h;
	tex.depth     = 1;
	tex.location  = GCM_LOCATION_RSX;
	tex.pitch     = t->pitch;
	tex.offset    = t->offset;

	rsxInvalidateTextureCache(g_ctx, GCM_INVALIDATE_TEXTURE);
	rsxLoadTexture(g_ctx, unit, &tex);
	rsxTextureControl(g_ctx, unit, GCM_TRUE, 0 << 8, 12 << 8, GCM_TEXTURE_MAX_ANISO_1);
	rsxTextureFilter(g_ctx, unit, 0, GcmFilter(t->minFilter), GcmFilter(t->magFilter),
	                 GCM_TEXTURE_CONVOLUTION_QUINCUNX);
	// Las texturas lineales no repiten: el juego solo usa CLAMP_TO_EDGE.
	rsxTextureWrapMode(g_ctx, unit, GCM_TEXTURE_CLAMP_TO_EDGE, GCM_TEXTURE_CLAMP_TO_EDGE,
	                   GCM_TEXTURE_CLAMP_TO_EDGE, 0, GCM_TEXTURE_ZFUNC_LESS, 0);

	t->dirty = false;
	g_curTex = t;
}

// ---------------------------------------------------------------------------
// Ring de vertices y envio de draws
// ---------------------------------------------------------------------------
bool RingAlloc(uint32_t bytes, OutVertex** cpu, uint32_t* off)
{
	bytes = (bytes + 127u) & ~127u;
	if (!g_ring || bytes > kRegionBytes) return false;
	if (g_ringUsed + bytes > kRegionBytes)
	{
		GpuIdle();          // la region se llena: esperar y reusarla desde el principio
		g_ringUsed = 0;
	}
	const uint32_t base = (uint32_t)(g_frame % kRegions) * kRegionBytes + g_ringUsed;
	*cpu = reinterpret_cast<OutVertex*>(static_cast<uint8_t*>(g_ring) + base);
	*off = g_ringOffset + base;
	g_ringUsed += bytes;
	return true;
}

// Los vertices ya estan en el ring (offset 'off', 'n' vertices).
void SubmitDraw(u32 gcmPrim, uint32_t off, int n, Tex* t, const Mat4& mvp)
{
	__sync_synchronize();   // vertices escritos antes de que RSX los lea

	if (!g_vpLoaded)
	{
		rsxLoadVertexProgram(g_ctx, g_vpo, g_vpUcode);
		g_vpLoaded = true;
		g_mvpValid = false;
	}
	if (!g_mvpValid || std::memcmp(g_lastMvp, mvp.m, sizeof(g_lastMvp)) != 0)
	{
		std::memcpy(g_lastMvp, mvp.m, sizeof(g_lastMvp));
		rsxSetVertexProgramParameter(g_ctx, g_vpo, g_mvpConst, g_lastMvp);
		g_mvpValid = true;
	}

	const int fp = t ? 1 : 0;
	if (g_curFp != fp)
	{
		rsxLoadFragmentProgramLocation(g_ctx, g_fp[fp].fpo, g_fp[fp].offset, GCM_LOCATION_RSX);
		g_curFp = fp;
	}
	if (t)
	{
		if (t != g_curTex || t->dirty)
			SetTexture(t);
		t->lastUsed = g_frame;
	}
	if (g_blendDirty)
		ApplyBlend();

	rsxSetVertexDataArray(g_ctx, (u8)g_attrPos, 0, sizeof(OutVertex), 3,
	                      GCM_VERTEX_DATA_TYPE_F32, GCM_LOCATION_RSX, off + 0);
	rsxSetVertexDataArray(g_ctx, (u8)g_attrCol, 0, sizeof(OutVertex), 4,
	                      GCM_VERTEX_DATA_TYPE_U8, GCM_LOCATION_RSX, off + 12);
	rsxSetVertexDataArray(g_ctx, (u8)g_attrUv, 0, sizeof(OutVertex), 2,
	                      GCM_VERTEX_DATA_TYPE_F32, GCM_LOCATION_RSX, off + 16);
	rsxDrawVertexArray(g_ctx, gcmPrim, 0, (u32)n);
}

// ---------------------------------------------------------------------------
// Lectura de los punteros de cliente (glVertexPointer & co)
// ---------------------------------------------------------------------------
size_t TypeBytes(GLenum t) { return t == GL_FLOAT ? 4 : (t == GL_UNSIGNED_BYTE ? 1 : 0); }

inline float ReadF(const uint8_t* p)
{
	float f;
	std::memcpy(&f, p, sizeof(f));
	return f;
}

inline uint8_t ClampByte(float f)
{
	if (f <= 0.0f) return 0;
	if (f >= 1.0f) return 255;
	return (uint8_t)(f * 255.0f + 0.5f);
}

bool ArraysUsable()
{
	const ClientArray& p = g_arr[0];
	if (!p.enabled || !p.ptr || p.type != GL_FLOAT || (p.size != 2 && p.size != 3)) return false;
	const ClientArray& c = g_arr[1];
	if (c.enabled && (!c.ptr || (c.type != GL_UNSIGNED_BYTE && c.type != GL_FLOAT) ||
	                  (c.size != 3 && c.size != 4))) return false;
	const ClientArray& u = g_arr[2];
	if (u.enabled && (!u.ptr || u.type != GL_FLOAT || u.size != 2)) return false;
	return true;
}

void ReadVertices(OutVertex* out, int first, int count)
{
	const ClientArray& P = g_arr[0];
	const ClientArray& C = g_arr[1];
	const ClientArray& U = g_arr[2];
	const size_t pStride = P.stride ? (size_t)P.stride : P.size * 4u;
	const size_t cStride = C.stride ? (size_t)C.stride : C.size * TypeBytes(C.type);
	const size_t uStride = U.stride ? (size_t)U.stride : 8u;

	for (int i = 0; i < count; ++i)
	{
		const size_t idx = (size_t)(first + i);
		OutVertex& v = out[i];

		const uint8_t* p = P.ptr + idx * pStride;
		v.x = ReadF(p);
		v.y = ReadF(p + 4);
		v.z = (P.size == 3) ? ReadF(p + 8) : 0.0f;

		v.r = v.g = v.b = v.a = 255;
		if (C.enabled)
		{
			const uint8_t* c = C.ptr + idx * cStride;
			if (C.type == GL_UNSIGNED_BYTE)
			{
				v.r = c[0]; v.g = c[1]; v.b = c[2];
				v.a = (C.size == 4) ? c[3] : 255;
			}
			else
			{
				v.r = ClampByte(ReadF(c));
				v.g = ClampByte(ReadF(c + 4));
				v.b = ClampByte(ReadF(c + 8));
				v.a = (C.size == 4) ? ClampByte(ReadF(c + 12)) : 255;
			}
		}

		v.u = v.v = 0.0f;
		if (U.enabled)
		{
			const uint8_t* t = U.ptr + idx * uStride;
			v.u = ReadF(t);
			v.v = ReadF(t + 4);
		}
	}
}

// ---------------------------------------------------------------------------
// Quad de prueba
// ---------------------------------------------------------------------------
// Fallback sin shaders (Parte 2): clear limitado por scissor.
void DrawTestQuadClear()
{
	const int size = g_height / 4;
	const int span = g_width - size;
	const int step = (int)(((uint32_t)g_frame * 6u) % (uint32_t)(2 * span));
	const int x    = (step < span) ? step : (2 * span - step);
	const int y    = (g_height - size) / 2;

	const float t = (float)(g_frame % 240) / 240.0f;
	rsxSetScissor(g_ctx, (u16)x, (u16)y, (u16)size, (u16)size);
	rsxSetClearColor(g_ctx, PackARGB(1.0f - t, 0.4f + 0.6f * t, t, 1.0f));
	rsxClearSurface(g_ctx, GCM_CLEAR_R | GCM_CLEAR_G | GCM_CLEAR_B | GCM_CLEAR_A);
	SetFullScissor();
}

// Quad texturizado (checkerboard generado por codigo) que rebota. Prueba todo
// el camino: shaders, matriz, textura, vertex ring y draw. No toca el estado GL
// del juego (textura enlazada, punteros, matrices).
void DrawTestQuadTextured()
{
	if (!g_testTex)
	{
		g_testTex = new Tex();
		g_testTex->minFilter = g_testTex->magFilter = GL_NEAREST;
		constexpr int N = 64;
		if (!TexAlloc(g_testTex, N, N)) { delete g_testTex; g_testTex = nullptr; return; }
		std::vector<uint8_t> px((size_t)N * N * 4);
		for (int y = 0; y < N; ++y)
			for (int x = 0; x < N; ++x)
			{
				const bool dark = (((x / 8) + (y / 8)) & 1) != 0;
				uint8_t* p = &px[((size_t)y * N + x) * 4];
				p[0] = dark ? 40 : 255; p[1] = dark ? 40 : 200; p[2] = dark ? 90 : 40; p[3] = 255;
			}
		TexUpload(g_testTex, 0, 0, N, N, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
	}

	const float size = (float)(g_height / 3);
	const float span = (float)g_width - size;
	const uint32_t step = ((uint32_t)g_frame * 6u) % (uint32_t)(2.0f * span);
	const float x0 = ((float)step < span) ? (float)step : (2.0f * span - (float)step);
	const float y0 = ((float)g_height - size) * 0.5f;

	OutVertex* v = nullptr;
	uint32_t   off = 0;
	if (!RingAlloc(4 * sizeof(OutVertex), &v, &off)) return;

	// TRIANGLE_STRIP: (0,0) (1,0) (0,1) (1,1)
	const float ux[4] = { 0, 1, 0, 1 }, uy[4] = { 0, 0, 1, 1 };
	for (int i = 0; i < 4; ++i)
	{
		v[i].x = x0 + ux[i] * size;
		v[i].y = y0 + uy[i] * size;
		v[i].z = 0.0f;
		v[i].r = v[i].g = v[i].b = v[i].a = 255;
		v[i].u = ux[i];
		v[i].v = uy[i];
	}
	// Ortho en pixeles, origen arriba-izquierda (igual que el juego).
	const Mat4 mvp = MatOrtho(0, g_width, g_height, 0, -1, 1);
	SubmitDraw(GCM_TYPE_TRIANGLE_STRIP, off, 4, g_testTex, mvp);
}

void DrawTestQuad()
{
	if (g_progsOk) DrawTestQuadTextured();
	else           DrawTestQuadClear();
}

// ---------------------------------------------------------------------------
// Cursor por software (Parte 4): flecha propia, negra con relleno blanco.
// ---------------------------------------------------------------------------
void DrawCursor()
{
	if (!g_cursorVisible || !g_progsOk) return;

	const float vw = (float)((g_vpW > 0) ? g_vpW : g_width);
	const float vh = (float)((g_vpH > 0) ? g_vpH : g_height);
	const float s  = vh / 720.0f * 1.15f;          // tamano relativo a 720p
	const float cx = g_cursorX * vw, cy = g_cursorY * vh;

	// Flecha en unidades (punta en 0,0): triangulo + cola.
	static const float shape[6][2] = {
		{ 0.0f, 0.0f }, { 0.0f, 17.0f }, { 11.0f, 12.0f },     // cabeza
		{ 4.0f, 12.0f }, { 7.5f, 21.0f }, { 11.0f, 19.5f },    // cola (1er triangulo)
	};
	static const float tail2[3][2] = { { 4.0f, 12.0f }, { 11.0f, 19.5f }, { 8.0f, 11.0f } };

	OutVertex* v = nullptr;
	uint32_t   off = 0;
	const int  N = 2 * 9;                           // 2 pasadas x 3 triangulos
	if (!RingAlloc(N * sizeof(OutVertex), &v, &off)) return;

	int n = 0;
	for (int pass = 0; pass < 2; ++pass)
	{
		const float grow = (pass == 0) ? 1.35f : 1.0f;      // borde negro, luego blanco
		const float shift = (pass == 0) ? -1.4f * s : 0.0f;
		const uint8_t c = (pass == 0) ? 0 : 255;
		auto put = [&](float ux, float uy) {
			OutVertex& o = v[n++];
			o.x = cx + shift + ux * s * grow;
			o.y = cy + shift + uy * s * grow;
			o.z = 0.0f;
			o.r = o.g = o.b = c; o.a = 255;
			o.u = o.v = 0.0f;
		};
		for (int i = 0; i < 6; ++i) put(shape[i][0], shape[i][1]);
		for (int i = 0; i < 3; ++i) put(tail2[i][0], tail2[i][1]);
	}
	SubmitDraw(GCM_TYPE_TRIANGLES, off, n, nullptr, MatOrtho(0, vw, vh, 0, -1, 1));
}

// ---------------------------------------------------------------------------
// Liberacion de recursos
// ---------------------------------------------------------------------------
void FreeBuffers()
{
	for (int i = 0; i < kBufferCount; ++i)
		if (g_color[i].ptr) { rsxFree(g_color[i].ptr); g_color[i].ptr = nullptr; }
	if (g_depth) { rsxFree(g_depth); g_depth = nullptr; }
	if (g_ring)  { rsxFree(g_ring);  g_ring  = nullptr; }
}

void FreeAllTextures()
{
	for (size_t i = 1; i < g_tex.size(); ++i)
	{
		if (g_tex[i]) { if (g_tex[i]->data) rsxFree(g_tex[i]->data); delete g_tex[i]; }
	}
	g_tex.assign(1, nullptr);
	g_freeIds.clear();
	if (g_testTex) { if (g_testTex->data) rsxFree(g_testTex->data); delete g_testTex; g_testTex = nullptr; }
	g_boundTex = 0;
	g_curTex = nullptr;
}

} // namespace

// ---------------------------------------------------------------------------
// API de pantalla
// ---------------------------------------------------------------------------
extern "C" {

bool ps3gl_init(void)
{
	if (g_inited) return true;

	// 1) RSX: command buffer + memoria host mapeada (alineada a 1 MB).
	g_host = memalign(1024 * 1024, PS3GL_HOST_SIZE);
	if (!g_host)
	{
		std::printf("[PS3][GL] memalign host fallo\n");
		return false;
	}
	if (rsxInit(&g_ctx, PS3GL_CMD_SIZE, PS3GL_HOST_SIZE, g_host) != 0 || !g_ctx)
	{
		std::printf("[PS3][GL] rsxInit fallo\n");
		std::free(g_host);
		g_host = nullptr;
		g_ctx = nullptr;
		return false;
	}

	// 2) Video: 720p si el display lo acepta; si no, el modo actual.
	videoState state;
	if (videoGetState(VIDEO_PRIMARY, 0, &state) != 0)
	{
		std::printf("[PS3][GL] videoGetState fallo\n");
		return false;
	}

	u32 resId = state.displayMode.resolution;
	if (videoGetResolutionAvailability(VIDEO_PRIMARY, VIDEO_RESOLUTION_720,
	                                   VIDEO_ASPECT_AUTO, 0) == 1)
		resId = VIDEO_RESOLUTION_720;

	videoResolution res;
	if (videoGetResolution(resId, &res) != 0)
	{
		std::printf("[PS3][GL] videoGetResolution fallo\n");
		return false;
	}

	videoConfiguration vconfig;
	std::memset(&vconfig, 0, sizeof(vconfig));
	vconfig.resolution = (u8)resId;
	vconfig.format     = VIDEO_BUFFER_FORMAT_XRGB;
	vconfig.pitch      = res.width * sizeof(u32);
	vconfig.aspect     = state.displayMode.aspect;

	if (videoConfigure(VIDEO_PRIMARY, &vconfig, nullptr, 0) != 0)
	{
		std::printf("[PS3][GL] videoConfigure fallo\n");
		return false;
	}
	videoGetState(VIDEO_PRIMARY, 0, &state);

	g_width  = (int)res.width;
	g_height = (int)res.height;
	g_pitch  = (uint32_t)g_width * sizeof(u32);
	g_depthPitch = (uint32_t)g_width * sizeof(u32);   // Z24S8 = 4 bytes/pixel

	gcmSetFlipMode(GCM_FLIP_VSYNC);

	// 3) Framebuffers (en memoria local de RSX) + depth.
	const uint32_t colorBytes = g_pitch * (uint32_t)g_height;
	const uint32_t depthBytes = g_depthPitch * (uint32_t)g_height;

	for (int i = 0; i < kBufferCount; ++i)
	{
		g_color[i].ptr = (uint32_t*)rsxMemalign(64, colorBytes);
		if (!g_color[i].ptr || rsxAddressToOffset(g_color[i].ptr, &g_color[i].offset) != 0)
		{
			std::printf("[PS3][GL] no hay memoria RSX para el framebuffer %d\n", i);
			FreeBuffers();
			return false;
		}
		std::memset(g_color[i].ptr, 0, colorBytes);   // negro inicial

		if (gcmSetDisplayBuffer((u8)i, g_color[i].offset, g_pitch,
		                        (u32)g_width, (u32)g_height) != 0)
		{
			std::printf("[PS3][GL] gcmSetDisplayBuffer(%d) fallo\n", i);
			FreeBuffers();
			return false;
		}
	}

	g_depth = (uint32_t*)rsxMemalign(64, depthBytes);
	if (!g_depth || rsxAddressToOffset(g_depth, &g_depthOff) != 0)
	{
		std::printf("[PS3][GL] no hay memoria RSX para el depth buffer\n");
		FreeBuffers();
		return false;
	}

	// 4) Ring de vertices (3 regiones, una por frame en vuelo).
	g_ring = rsxMemalign(128, kRegionBytes * kRegions);
	if (!g_ring || rsxAddressToOffset(g_ring, &g_ringOffset) != 0)
	{
		std::printf("[PS3][GL] no hay memoria RSX para el ring de vertices\n");
		FreeBuffers();
		return false;
	}

	// 5) Shaders. Si faltan, el backend queda en modo Parte 2 (solo clear).
	g_progsOk = InitPrograms();
	if (!g_progsOk)
	{
		FreePrograms();
		std::printf("[PS3][GL] SIN shaders: glDrawArrays no dibuja (solo quad por clear)\n");
	}

	// 6) Callback del XMB (PS button -> salir del juego, etc.).
#if PS3GL_HANDLE_SYSUTIL
	sysUtilRegisterCallback(0, SysutilCallback, nullptr);
#endif

	// 7) Estado GL inicial.
	g_proj = MatIdentity();
	g_mv   = MatIdentity();
	g_matrixMode = GL_MODELVIEW;
	g_vpX = g_vpY = 0;
	g_vpW = g_width;
	g_vpH = g_height;
	g_frame = 0;
	g_ringUsed = 0;

	// 8) Flip inicial al buffer 1 (negro). Deja el flip-status "pendiente" para
	//    que el primer WaitFlip de swap_buffers tenga algo que esperar; el primer
	//    frame se dibuja en el buffer 0.
	gcmResetFlipStatus();
	if (!QueueFlip(1))
		std::printf("[PS3][GL] flip inicial fallo\n");

	g_back   = 0;
	g_inited = true;

	// Window.cpp solo llama a init: el primer frame se prepara aca.
	ps3gl_begin_frame();

	std::printf("[PS3][GL] RSX listo: %dx%d, 2 framebuffers, depth Z24S8, vsync, shaders=%s\n",
	            g_width, g_height, g_progsOk ? "si" : "no");
	return true;
}

void ps3gl_begin_frame(void)
{
	if (!g_inited) return;

#if PS3GL_HANDLE_SYSUTIL
	sysUtilCheckCallback();   // procesa eventos del XMB
#endif

	ReleaseDeferred(false);
	g_ringUsed = 0;
	// RSX conserva estado entre frames, pero se invalida el cache propio: cada
	// frame recarga programas/textura/blend una vez (barato, y a prueba de errores).
	g_vpLoaded = false;
	g_mvpValid = false;
	g_curFp    = -1;
	g_curTex   = nullptr;
	g_blendDirty = true;

	SetRenderTarget(g_back);
	ApplyGlState();
	ApplyViewport();
	ClearColorAndDepth(g_clearColor);
}

void ps3gl_swap_buffers(void)
{
	if (!g_inited) return;

	if (PS3GL_TEST_QUAD || g_selftest)
		DrawTestQuad();

	DrawCursor();

	// Espera (con vsync) a que el flip anterior se haya ejecutado, y recien
	// entonces encola el nuevo. Es lo que mantiene los 60 Hz.
	WaitFlip();
	QueueFlip(g_back);
	g_back ^= 1;
	++g_frame;
}

void ps3gl_shutdown(void)
{
	if (!g_inited) return;

	// Deja que RSX termine todo y que el ultimo flip se ejecute antes de liberar
	// los buffers que se estan mostrando.
	gcmSetWaitFlip(g_ctx);
	GpuIdle();
	WaitFlip();

	FreeAllTextures();
	ReleaseDeferred(true);
	FreePrograms();
	FreeBuffers();
	std::free(g_host);
	g_host = nullptr;
	g_ctx = nullptr;
	g_inited = false;
}

int ps3gl_width(void)  { return g_width; }
int ps3gl_height(void) { return g_height; }

bool ps3gl_exit_requested(void) { return g_exitReq; }

void ps3gl_set_cursor(float x, float y, bool visible)
{
	g_cursorX = x; g_cursorY = y; g_cursorVisible = visible;
}

bool ps3gl_selftest(int frames)
{
	if (!ps3gl_init()) return false;
	g_selftest = true;
	for (int i = 0; i < frames && !g_exitReq; ++i)
	{
		ps3gl_swap_buffers();
		ps3gl_begin_frame();
	}
	g_selftest = false;
	ps3gl_shutdown();
	return true;
}

// ---------------------------------------------------------------------------
// OpenGL 1.x minimo
// ---------------------------------------------------------------------------
void glEnable(GLenum cap)
{
	switch (cap)
	{
	case GL_BLEND:      g_blend = true;       g_blendDirty = true; break;
	case GL_DEPTH_TEST: g_depthTest = true;
		if (g_inited) { rsxSetDepthTestEnable(g_ctx, GCM_TRUE); rsxSetDepthWriteEnable(g_ctx, GCM_TRUE); }
		break;
	case GL_TEXTURE_2D: g_texEnabled = true;  break;
	default: break;   // CULL_FACE, DITHER, LIGHTING: RSX no los usa en este backend
	}
}

void glDisable(GLenum cap)
{
	switch (cap)
	{
	case GL_BLEND:      g_blend = false;      g_blendDirty = true; break;
	case GL_DEPTH_TEST: g_depthTest = false;
		if (g_inited) { rsxSetDepthTestEnable(g_ctx, GCM_FALSE); rsxSetDepthWriteEnable(g_ctx, GCM_FALSE); }
		break;
	case GL_TEXTURE_2D: g_texEnabled = false; break;
	default: break;
	}
}

void glBlendFunc(GLenum sfactor, GLenum dfactor)
{
	g_blendSrc = sfactor;
	g_blendDst = dfactor;
	g_blendDirty = true;
}

void glEnableClientState(GLenum array)
{
	if      (array == GL_VERTEX_ARRAY)        g_arr[0].enabled = true;
	else if (array == GL_COLOR_ARRAY)         g_arr[1].enabled = true;
	else if (array == GL_TEXTURE_COORD_ARRAY) g_arr[2].enabled = true;
}

void glDisableClientState(GLenum array)
{
	if      (array == GL_VERTEX_ARRAY)        g_arr[0].enabled = false;
	else if (array == GL_COLOR_ARRAY)         g_arr[1].enabled = false;
	else if (array == GL_TEXTURE_COORD_ARRAY) g_arr[2].enabled = false;
}

void glVertexPointer(GLint size, GLenum type, GLsizei stride, const GLvoid* ptr)
{
	g_arr[0].size = size; g_arr[0].type = type; g_arr[0].stride = stride;
	g_arr[0].ptr = static_cast<const uint8_t*>(ptr);
}

void glColorPointer(GLint size, GLenum type, GLsizei stride, const GLvoid* ptr)
{
	g_arr[1].size = size; g_arr[1].type = type; g_arr[1].stride = stride;
	g_arr[1].ptr = static_cast<const uint8_t*>(ptr);
}

void glTexCoordPointer(GLint size, GLenum type, GLsizei stride, const GLvoid* ptr)
{
	g_arr[2].size = size; g_arr[2].type = type; g_arr[2].stride = stride;
	g_arr[2].ptr = static_cast<const uint8_t*>(ptr);
}

void glClearColor(GLclampf r, GLclampf g, GLclampf b, GLclampf a)
{
	g_clearColor = PackARGB(r, g, b, a);
}

void glClear(GLbitfield mask)
{
	if (!g_inited || !(mask & GL_COLOR_BUFFER_BIT)) return;
	ClearColorAndDepth(g_clearColor);
}

void glViewport(GLint x, GLint y, GLsizei w, GLsizei h)
{
	g_vpX = x; g_vpY = y; g_vpW = w; g_vpH = h;
	if (g_inited) ApplyViewport();
}

void glMatrixMode(GLenum mode)
{
	if (mode == GL_MODELVIEW || mode == GL_PROJECTION) g_matrixMode = mode;
	else SetError(kGlInvalidEnum);
}

void glLoadIdentity(void)
{
	(g_matrixMode == GL_PROJECTION ? g_proj : g_mv) = MatIdentity();
}

void glOrtho(GLdouble l, GLdouble r, GLdouble b, GLdouble t, GLdouble n, GLdouble f)
{
	Mat4& m = (g_matrixMode == GL_PROJECTION) ? g_proj : g_mv;
	m = MatMul(m, MatOrtho(l, r, b, t, n, f));
}

void glGenTextures(GLsizei n, GLuint* textures)
{
	for (GLsizei i = 0; i < n; ++i)
		textures[i] = TexNewName();
}

void glDeleteTextures(GLsizei n, const GLuint* textures)
{
	for (GLsizei i = 0; i < n; ++i)
	{
		const GLuint id = textures[i];
		if (id == 0 || id >= g_tex.size() || !g_tex[id]) continue;
		Tex* t = g_tex[id];
		if (t == g_curTex)  g_curTex = nullptr;
		if (id == g_boundTex) g_boundTex = 0;
		TexRelease(t);      // la memoria se libera 3 frames despues (la GPU puede estar leyendola)
		delete t;
		g_tex[id] = nullptr;
		g_freeIds.push_back(id);
	}
}

void glBindTexture(GLenum target, GLuint texture)
{
	if (target != GL_TEXTURE_2D) { SetError(kGlInvalidEnum); return; }
	if (texture != 0) TexFromName(texture);   // GL permite enlazar un nombre nuevo
	g_boundTex = texture;
}

void glTexParameteri(GLenum target, GLenum pname, GLint param)
{
	if (target != GL_TEXTURE_2D) return;
	Tex* t = (g_boundTex < g_tex.size()) ? g_tex[g_boundTex] : nullptr;
	if (!t) return;
	if (pname == GL_TEXTURE_MIN_FILTER)      { t->minFilter = (GLenum)param; t->dirty = true; }
	else if (pname == GL_TEXTURE_MAG_FILTER) { t->magFilter = (GLenum)param; t->dirty = true; }
	// WRAP_S/T: RSX lineal solo clampa; el juego solo pide CLAMP_TO_EDGE.
}

void glTexImage2D(GLenum target, GLint level, GLint /*internalformat*/, GLsizei w, GLsizei h,
                  GLint /*border*/, GLenum format, GLenum type, const GLvoid* pixels)
{
	if (target != GL_TEXTURE_2D || level != 0) return;
	if (!g_inited) { SetError(GL_OUT_OF_MEMORY); return; }
	Tex* t = (g_boundTex < g_tex.size()) ? g_tex[g_boundTex] : nullptr;
	if (!t) return;
	if (pixels && !FormatSupported(format, type)) { SetError(kGlInvalidEnum); return; }

	// Si cambia el tamano, TexAlloc libera la memoria vieja de forma diferida.
	if (!TexAlloc(t, w, h)) { SetError(GL_OUT_OF_MEMORY); return; }

	if (pixels)
	{
		TexUpload(t, 0, 0, w, h, format, type, pixels);
	}
	else
	{
		EnsureTexIdle(t);
		std::memset(t->data, 0, (size_t)t->pitch * t->h);
		t->dirty = true;
	}
}

void glTexSubImage2D(GLenum target, GLint level, GLint xoff, GLint yoff, GLsizei w, GLsizei h,
                     GLenum format, GLenum type, const GLvoid* pixels)
{
	if (target != GL_TEXTURE_2D || level != 0 || !pixels) return;
	Tex* t = (g_boundTex < g_tex.size()) ? g_tex[g_boundTex] : nullptr;
	if (!t || !t->data) { SetError(kGlInvalidValue); return; }
	if (!FormatSupported(format, type)) { SetError(kGlInvalidEnum); return; }
	if (!TexUpload(t, xoff, yoff, w, h, format, type, pixels)) SetError(kGlInvalidValue);
}

// Solo BGRA / 8_8_8_8_REV (lo unico que usa el juego, en el camino de recuperacion).
void glGetTexImage(GLenum target, GLint level, GLenum format, GLenum type, GLvoid* pixels)
{
	if (target != GL_TEXTURE_2D || level != 0 || !pixels) return;
	Tex* t = (g_boundTex < g_tex.size()) ? g_tex[g_boundTex] : nullptr;
	if (!t || !t->data) return;
	if (format != GL_BGRA || type != GL_UNSIGNED_INT_8_8_8_8_REV) { SetError(kGlInvalidEnum); return; }

	GpuIdle();   // que cualquier escritura de RSX a esta textura haya terminado
	uint32_t* dst = static_cast<uint32_t*>(pixels);
	for (int y = 0; y < t->h; ++y)
	{
		const uint32_t* src = reinterpret_cast<const uint32_t*>(
			reinterpret_cast<const uint8_t*>(t->data) + (size_t)y * t->pitch);
		std::memcpy(dst + (size_t)y * t->w, src, (size_t)t->w * 4);
	}
}

void glDrawArrays(GLenum mode, GLint first, GLsizei count)
{
	if (!g_inited || !g_progsOk || count <= 0 || first < 0) return;
	if (!ArraysUsable()) { SetError(kGlInvalidEnum); return; }

	u32  prim;
	int  outCount;
	bool fan = false;
	switch (mode)
	{
	case GL_TRIANGLES:
		count -= count % 3;
		if (count < 3) return;
		prim = GCM_TYPE_TRIANGLES; outCount = count; break;
	case GL_TRIANGLE_STRIP:
		if (count < 3) return;
		prim = GCM_TYPE_TRIANGLE_STRIP; outCount = count; break;
	case GL_TRIANGLE_FAN:
		if (count < 3) return;
		prim = GCM_TYPE_TRIANGLES; outCount = (count - 2) * 3; fan = true; break;
	case GL_LINE_STRIP:
		if (count < 2) return;
		prim = GCM_TYPE_LINE_STRIP; outCount = count; break;
	default:
		SetError(kGlInvalidEnum);
		return;
	}

	// Se lee a un buffer normal (cacheado) y se copia al ring de forma secuencial:
	// la memoria de RSX es lenta de leer y conviene solo escribirla.
	if (g_scratch.size() < (size_t)count) g_scratch.resize((size_t)count);
	ReadVertices(g_scratch.data(), first, count);

	OutVertex* dst = nullptr;
	uint32_t   off = 0;
	if (!RingAlloc((uint32_t)outCount * sizeof(OutVertex), &dst, &off))
	{
		SetError(GL_OUT_OF_MEMORY);
		return;
	}

	if (fan)
	{
		const OutVertex* s = g_scratch.data();
		for (int k = 1; k + 1 < count; ++k)
		{
			*dst++ = s[0];
			*dst++ = s[k];
			*dst++ = s[k + 1];
		}
	}
	else
	{
		std::memcpy(dst, g_scratch.data(), (size_t)count * sizeof(OutVertex));
	}

	Tex* t = nullptr;
	if (g_texEnabled && g_boundTex < g_tex.size())
	{
		t = g_tex[g_boundTex];
		if (t && !t->data) t = nullptr;
	}

	SubmitDraw(prim, off, outCount, t, MatMul(g_proj, g_mv));
}

GLenum glGetError(void) { GLenum e = sLastError; sLastError = GL_NO_ERROR; return e; }

void glGetIntegerv(GLenum pname, GLint* params)
{
	if (pname == GL_MAX_TEXTURE_SIZE) *params = PS3GL_MAX_TEXTURE_SIZE; else *params = 0;
}

} // extern "C"
#endif
