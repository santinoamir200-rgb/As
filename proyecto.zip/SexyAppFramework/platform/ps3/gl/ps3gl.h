#pragma once
// Integracion de pantalla PS3 (equivale a platform/wii/gx_wii.h):
// arranca RSX, crea los framebuffers y hace el flip. Las funciones glXxx las
// implementa ps3gl.cpp (Parte 2: video; Parte 3: shaders, texturas y dibujo).
#ifdef PS3_PLATFORM
#include <GL/gl.h>
extern "C" {
bool ps3gl_init(void);          // RSX + framebuffers. Devuelve false si falla.
void ps3gl_begin_frame(void);   // apunta RSX al back buffer, viewport/scissor, limpia
void ps3gl_swap_buffers(void);  // espera el flip anterior (vsync) y hace el flip nuevo
void ps3gl_shutdown(void);
int  ps3gl_width(void);         // resolucion real (720p si el display la acepta)
int  ps3gl_height(void);

// Parte 2 -------------------------------------------------------------------
// true cuando el XMB pidio cerrar el juego (menu PS -> "Salir del juego").
// Hay que consultarlo desde el bucle principal (Parte 4, junto al pad).
bool ps3gl_exit_requested(void);

// Prueba autonoma de RSX: init + N frames con el quad de color + shutdown.
// No necesita el juego: llamarla a mano desde main() para validar el video.
// Devuelve false si ps3gl_init fallo.
bool ps3gl_selftest(int frames);

// Parte 4: cursor por software. (x, y) normalizados 0..1 sobre el viewport GL
// actual (el area de juego); se dibuja encima de cada frame en swap_buffers.
void ps3gl_set_cursor(float x, float y, bool visible);
}
#endif
