#!/usr/bin/env bash
# Compila pvz_ps3.elf con ps3toolchain (PSL1GHT). Parte 1: solo el ELF.
# Uso:  ./build_ps3.sh            (build incremental)
#       ./build_ps3.sh clean      (borra build-ps3 antes)
set -euo pipefail
cd "$(dirname "$0")"

export PS3DEV="${PS3DEV:-/usr/local/ps3dev}"
export PSL1GHT="${PSL1GHT:-$PS3DEV}"
export PATH="$PS3DEV/bin:$PS3DEV/ppu/bin:$PATH"

[ "${1:-}" = "clean" ] && rm -rf build-ps3

# Parte 3: los shaders se compilan con cgcomp dentro de CMake; si no esta, se
# usan los de shaders/precompiled (generados con ./build_shaders.sh).
if ! command -v cgcomp >/dev/null && [ ! -x "$PS3DEV/bin/cgcomp" ] && \
   ! ls SexyAppFramework/platform/ps3/gl/shaders/precompiled/*.vpo >/dev/null 2>&1; then
	echo "AVISO: no hay cgcomp ni shaders precompilados; CMake va a abortar." >&2
fi

cmake -G Ninja -B build-ps3 \
	-DCMAKE_TOOLCHAIN_FILE=CMake/ps3_toolchain.cmake \
	-DCMAKE_BUILD_TYPE=Release \
	-DSEXY_LOG_LEVEL=1
cmake --build build-ps3 -j"$(nproc)"

echo
echo "Listo: build-ps3/pvz_ps3.elf"
echo "Siguiente: ./package_ps3.sh  (genera .self y .pkg)"
